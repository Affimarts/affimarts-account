# Affimarts Account — Deployment Guide

This guide takes the account system from these files to a working deployment on
**affimarts.com**, using only Google Apps Script, Google Sheets, HTML, CSS and
vanilla JavaScript.

There are two halves:

| Half | Where it lives | What it does |
| --- | --- | --- |
| Backend | Google Apps Script project | Registration, login, sessions, verification, reset, profile, favourites |
| Frontend | Your website (Blogger page + hosted CSS/JS) | MY ACCOUNT button, popup, forms, dashboard |

---

## 0. What you need

- A Google account that owns the Apps Script project (this account sends the
  verification and reset emails).
- The spreadsheet you supplied:
  <https://docs.google.com/spreadsheets/d/1wzIcUZPb4gGltN5TxAKYQIGWwObCkRdEuOIKHLWRqT4/edit>
  — its ID is already set in `Configuration.gs`.
- Access to edit the Affimarts Blogger theme (or wherever the mega menu lives).
- Somewhere to host three kinds of static file: `account.css`, the seven `.js`
  files, and `index.html` (the account page). GitHub Pages, Cloudflare Pages,
  Netlify, or the Blogger theme itself all work. Section 5 compares them.

---

## 1. Create the Apps Script project

1. Open <https://script.google.com> and click **New project**.
2. Rename it **Affimarts Account** (click the project title).
3. Delete the default `Code.gs` content.
4. Create one script file per backend file and paste the contents:

   | File to create | Source file in this folder |
   | --- | --- |
   | `Configuration` | `google-apps-script/Configuration.gs` |
   | `Security` | `google-apps-script/Security.gs` |
   | `Database` | `google-apps-script/Database.gs` |
   | `Sessions` | `google-apps-script/Sessions.gs` |
   | `EmailService` | `google-apps-script/EmailService.gs` |
   | `Authentication` | `google-apps-script/Authentication.gs` |
   | `Profile` | `google-apps-script/Profile.gs` |
   | `Favorites` | `google-apps-script/Favorites.gs` |
   | `Code` | `google-apps-script/Code.gs` |

   Apps Script adds `.gs` automatically; the names must match because functions
   are global. File order does not matter.
5. Click **Save** (Ctrl/Cmd + S).

> Do not add `appsscript.json` unless you need to. The defaults are fine. The
> project does not need any advanced Google services or external libraries.

---

## 2. Create the sheets (one-time)

1. In the Apps Script editor, choose the function **`initializeDatabase`** from
   the function dropdown and click **Run**.
2. Google asks for authorisation the first time:
   **Review permissions → choose the owning account → Advanced → Go to
   Affimarts Account (unsafe) → Allow.** The “unsafe” warning is normal for a
   personal, unpublished script. Approve **all** scopes shown (Sheets and
   Gmail/MailApp); if you add a new Google service later, run any function again
   to re-authorise before deploying.
3. Open the spreadsheet. You should now have exactly these tabs and headers:

   **Users** — `User ID | Full Name | Email | Password Hash | Password Salt |
   Mobile Number | Gender | Date of Birth | Registration Date | Account Status |
   Email Verified | Last Login | Updated At`

   **Sessions** — `Session ID | User ID | Session Token Hash | Created At |
   Expires At | Revoked`

   **PasswordReset** — `User ID | Reset Token Hash | Created At | Expires At |
   Used`

   **EmailVerification** — `User ID | Verification Token Hash | Created At |
   Expires At | Used`

   **Favorites** — `Favorite ID | User ID | Product Title | Product URL |
   Image URL | Added At`

`initializeDatabase()` is safe to run again: it creates missing sheets and
headers, and never deletes rows.

### Optional: remote initialisation

The `initializeDatabase` API action is disabled unless a Script Property named
`AFM_SETUP_KEY` exists:

1. **Project Settings (gear) → Script Properties → Add script property**
2. Property: `AFM_SETUP_KEY`, Value: a long random string.
3. Call the API with `{ "action": "initializeDatabase", "data": { "setupKey": "…" } }`.

Most people should simply run the function from the editor and leave the setup
key unset.

---

## 3. Deploy the web app

1. Click **Deploy → New deployment**.
2. Click the gear next to “Select type” and choose **Web app**.
3. Fill in:
   - **Description:** `Affimarts account v1`
   - **Execute as:** `Me (your-account@gmail.com)`
   - **Who has access:** `Anyone`
4. Click **Deploy**, then **Authorize access** if prompted.
5. Copy the **Web app URL**. It looks like:

   ```
   https://script.google.com/macros/s/AKfycb.../exec
   ```

6. Paste it into a browser tab and add `?action=health`. You should see:

   ```json
   {"success":true,"code":"OK","message":"Affimarts account API is running.","data":{"status":"ok",...}}
   ```

If you see an HTML login page instead, “Who has access” is not **Anyone**.
If you see “Script function not found: doGet”, the deployment was created
before `Code.gs` was saved — save and deploy a new version.

> **Keep this URL.** It stays stable when you edit the existing deployment.
> Do not create a brand-new deployment for every change; use
> **Manage deployments → edit (pencil) → Version: New version → Deploy**.

---

## 4. Configure the frontend

Open `affimarts-account/js/config.js` and set:

```js
window.AFM_CONFIG = {
  API_URL: 'https://script.google.com/macros/s/AKfycb.../exec',
  ACCOUNT_PAGE: 'https://www.affimarts.com/p/my-account.html',
  SITE_URL: 'https://www.affimarts.com',
  AUTO_POPUP: true,
  POPUP_DELAY_MS: 3000,
  REQUEST_TIMEOUT_MS: 30000,
  DEBUG: false
};
```

| Key | Meaning |
| --- | --- |
| `API_URL` | The `/exec` URL from step 3. **Required.** |
| `ACCOUNT_PAGE` | Page that hosts the dashboard. Used by “Account page”, menu links, and hash navigation. |
| `SITE_URL` | Storefront home for “Continue shopping”. |
| `AUTO_POPUP` | `false` disables the automatic 3-second sign-in prompt everywhere. |
| `POPUP_DELAY_MS` | Delay before the automatic prompt (default `3000`). |
| `REQUEST_TIMEOUT_MS` | Client timeout for API calls. |
| `DEBUG` | Logs request timing only — never tokens or passwords. |

`ACCOUNT_PAGE` must match the page where you publish `index.html`. If you host
the account page somewhere else, update it here and in
`Configuration.gs → ACCOUNT_PAGE_URL` (step 7).

---

## 5. Publish the frontend

You need to publish:

```
affimarts-account/
├── index.html          ← the account page (guest + dashboard)
├── css/account.css
└── js/
    ├── config.js
    ├── validation.js
    ├── session.js
    ├── authentication.js
    ├── profile.js
    ├── favorites.js
    └── account.js
```

### Option A — GitHub Pages (recommended)

1. Create a repository, e.g. `affimarts-account`.
2. Upload the `affimarts-account` folder contents (keep the `css/` and `js/`
   subfolders).
3. **Settings → Pages → Source: Deploy from a branch → main / (root) → Save.**
4. Your files are now at:

   ```
   https://YOURNAME.github.io/affimarts-account/index.html
   https://YOURNAME.github.io/affimarts-account/css/account.css
   https://YOURNAME.github.io/affimarts-account/js/config.js
   … etc.
   ```

5. Set `ACCOUNT_PAGE` to the `index.html` URL (or a custom domain path).

Every future update is just “commit to the repository”. GitHub Pages serves
HTTPS, which the “Remember me” cookie requires (`Secure`).

### Option B — jsDelivr from GitHub

Once the repository is public you can serve the assets without enabling Pages:

```
https://cdn.jsdelivr.net/gh/YOURNAME/affimarts-account@main/css/account.css
https://cdn.jsdelivr.net/gh/YOURNAME/affimarts-account@main/js/config.js
…
```

Pin a tag (`@v1.0.0`) instead of `@main` for cache-safe production releases.
The account page itself still needs a normal host.

### Option C — Cloudflare Pages / Netlify

Drag the `affimarts-account` folder into the dashboard. Both provide HTTPS and
a stable URL. No build step is required.

### Option D — Inside Blogger only

Blogger can host the CSS and JS inside the theme, but it is the least
maintainable option:

- CSS: paste `account.css` inside the existing `<style>` block (or a second
  `<style>` in `<head>`).
- JS: paste each file inside its own `<script>` block, **in the same order** as
  the `<script src>` tags, just before `</body>`.
- Account page: **Pages → New page → HTML view** and paste the contents of
  `index.html` **without** the `<!doctype>`, `<html>`, `<head>` and `<body>`
  wrapper (Blogger supplies those). Move the `<link>` and `<script>` tags into
  the page or the theme.

Blogger sometimes rewrites raw `<` characters in the page editor. If the page
renders as text, host it with Option A and link to it instead.

---

## 6. Put MY ACCOUNT into the mega menu

`New Mega Menu.html` has already been updated:

- The old **TRENDING** anchor was replaced, in the same position, by the
  MY ACCOUNT button markup (`.afm-account`).
- A stylesheet link and seven script tags were added.

Before publishing to Blogger, replace the relative URLs with your hosted URLs:

```html
<!-- in <head> -->
<link rel="stylesheet" href="https://YOUR-HOST/affimarts-account/css/account.css">

<!-- before </body>, in this order -->
<script src="https://YOUR-HOST/affimarts-account/js/config.js"></script>
<script src="https://YOUR-HOST/affimarts-account/js/validation.js"></script>
<script src="https://YOUR-HOST/affimarts-account/js/session.js"></script>
<script src="https://YOUR-HOST/affimarts-account/js/authentication.js"></script>
<script src="https://YOUR-HOST/affimarts-account/js/profile.js"></script>
<script src="https://YOUR-HOST/affimarts-account/js/favorites.js"></script>
<script src="https://YOUR-HOST/affimarts-account/js/account.js"></script>
```

If you use Option D (everything inside Blogger), keep the relative paths and
upload the `affimarts-account` folder into the Blogger theme’s file storage, or
paste the files inline.

Nothing else in the mega menu needs to change. The original file is preserved
as `New Mega Menu.original.html` for diffing or rollback.

### Verify the button

- Desktop: the button sits exactly where TRENDING was, between the search icon
  and the burger, with the wine background and gold underline on hover.
- Logged out: it reads **My Account** with a person icon.
- Logged in: it shows the user’s first name and a gold initials avatar.
- Clicking it opens the panel anchored under the button (desktop) or as a
  centred modal (≤1020px).
- Three seconds after load, signed-out visitors see the sign-in panel. It does
  not reopen in the same tab after being dismissed. It never opens for
  signed-in users.

---

## 7. Point email links at the account page

Email links are built from `Configuration.gs → ACCOUNT_PAGE_URL`:

```js
ACCOUNT_PAGE_URL: 'https://www.affimarts.com/p/my-account.html',
```

Set this to the public URL of your account page. It must be reachable by the
recipient. If you leave it blank, links fall back to the Apps Script URL, which
shows a branded confirmation page instead.

After changing `Configuration.gs`:

1. **Save.**
2. **Deploy → Manage deployments → pencil → Version: New version → Deploy.**

The `/exec` URL does not change.

### Email behaviour

- Verification link: `…/my-account.html?verify=TOKEN` — opens the account panel
  with a **Confirm my email** button. The account is not marked verified until
  that button (or the fallback page’s button) is pressed, so email link scanners
  cannot consume the token.
- Reset link: `…/my-account.html?reset=TOKEN` — opens the **Choose a new
  password** view. The token expires after 30 minutes and works once.
- Sender name: `Affimarts`. The From address is the Google account that owns
  the script. Set `REPLY_TO` and `SUPPORT_EMAIL` in `Configuration.gs` if you
  want replies to go elsewhere.
- Quota: a consumer Gmail account can email about **100 recipients/day**
  (Google Workspace: ~1,500). Registration and reset emails share this quota.
  For a busy launch, use a Workspace account or move email to a dedicated
  transactional provider later.

---

## 8. Post-deployment test checklist

Run these against the live site, in this order. Use a real inbox you can open.

**Bootstrap**
- [ ] `GET <API_URL>?action=health` returns `"status":"ok"`.
- [ ] Spreadsheet contains the five tabs with the headers from step 2.

**Registration**
- [ ] Open the site signed out. After 3 seconds the panel slides in under the
      button (desktop) or centred (mobile).
- [ ] Close it with ×, Escape, and an outside click. Reload: it does not reopen
      in the same tab.
- [ ] Create an account. Required fields validate; optional mobile, gender and
      date of birth are accepted.
- [ ] A second registration with the same email (any casing) is rejected.
- [ ] The confirmation email arrives; the link opens the account page with a
      **Confirm my email** button.
- [ ] Before confirming, signing in returns “confirm your email first”.
- [ ] After confirming, the Users row shows `Email Verified = TRUE`.
- [ ] The same link cannot be used twice.

**Login and sessions**
- [ ] Wrong password shows a structured error and the password is selected.
- [ ] Six rapid failures trigger a throttling message.
- [ ] Correct login closes the panel, shows a welcome toast, and changes the
      header button to the first name + initials.
- [ ] “Remember me” keeps you signed in after closing the tab (cookie). Without
      it, a new tab is signed out (sessionStorage).
- [ ] Reloading the page keeps the signed-in state (server validation).
- [ ] Logout returns the button to **My Account** and clears storage.

**Dashboard** (`/p/my-account.html`)
- [ ] My Profile shows name, email, mobile, date of birth, gender, member
      since, last login, email status and favourites count.
- [ ] Edit Profile saves changes and they persist after reload.
- [ ] Account Settings → Change password rejects a wrong current password,
      accepts a strong new one, and signs out other devices.
- [ ] “Sign out of all devices” requires a second click and then signs out.
- [ ] Preferences toggle the sign-in prompt and reduced motion on this device.

**Favourites**
- [ ] Add a favourite with the dashboard link form; it appears with title,
      image (or letter fallback), **View product** and **Remove**.
- [ ] Adding the same URL twice reports “Already in your favourites”.
- [ ] Another account cannot see or remove it.
- [ ] A product page save button works if you added `data-afm-save` (step 10).

**Password reset**
- [ ] “Forgot password?” always shows the same generic confirmation, for known
      and unknown emails.
- [ ] The reset email link opens the new-password view.
- [ ] A weak password is rejected; a strong one succeeds and signs out all
      sessions.
- [ ] Reusing the link reports that it has already been used.
- [ ] After 30 minutes (or by editing `Expires At` in the sheet) the link is
      rejected as expired.

**Responsive**
- [ ] At 360px, 768px and 1440px there is no horizontal scrollbar.
- [ ] The popup is a centred modal with a dimmed backdrop on mobile.
- [ ] The dashboard tabs scroll horizontally on small screens and all forms are
      usable with one hand.

---

## 9. Adding save buttons to product pages

Any element with `data-afm-save` becomes a favourite button. The account scripts
must be loaded on that page.

```html
<button type="button"
        data-afm-save
        data-afm-title="Zeel Clothing Black Georgette Lehenga"
        data-afm-url="https://www.affimarts.com/2026/09/zeel-clothing-womens-black-georgette.html"
        data-afm-image="https://m.media-amazon.com/images/I/71webzS9TiL._SY741_.jpg">
  <span data-afm-save-label>Save</span>
</button>
```

- `data-afm-title` and `data-afm-url` are required.
- `data-afm-image` is optional; the dashboard falls back to a letter tile.
- If the visitor is signed out, the sign-in panel opens and a toast explains why.
- After a successful save the label becomes **Saved** and the button gets the
  `is-saved` class for styling.

For dynamically inserted cards, call `AFM.favorites.bindSaveButtons(container)`
after inserting the markup.

Allowed favourite URLs: `http(s)` links on `affimarts.com`, `amazon.in`,
`amazon.com`, `amzn.to`, `amzn.in`, `link.amazon`, `flipkart.com`, `fkrt.co`,
`myntra.com`, `ajio.com` and `meesho.com`. Edit the allow-list in
`Security.gs` (`afmNormalizeProductUrl_`) if you add stores.

---

## 10. Day-to-day operations

### Updating the backend

1. Edit the `.gs` file in the editor.
2. **Save.**
3. **Deploy → Manage deployments → pencil → Version: New version → Deploy.**

The frontend needs no change unless the request/response contract changes.

### Updating the frontend

Commit the changed file to your host. If you use jsDelivr with a pinned tag,
publish a new tag and update the URLs.

### Backups

The spreadsheet is the database:

- **File → Make a copy** weekly, or
- **File → Version history** for point-in-time recovery.

Never store a second copy of password hashes in email, chat or a public repo.

### Housekeeping

- Expired sessions are pruned automatically during session creation (roughly
  15% of logins trigger a sweep). Revoked sessions are ignored immediately.
- `PasswordReset` and `EmailVerification` rows accumulate. They are small; you
  can delete rows older than 90 days by hand if you prefer. Never delete a row
  while its token could still be valid (48h verification, 30min reset).
- To disable an account without deleting it, set its `Account Status` cell to
  `disabled`. Login and session validation then fail.

### Changing configuration

Every key in `Configuration.gs` can be overridden with a Script Property named
`AFM_<KEY>`:

| Property | Effect |
| --- | --- |
| `AFM_SESSION_TTL_MINUTES` | Normal session length (default 120). |
| `AFM_SESSION_REMEMBER_DAYS` | Remember-me length (default 30). |
| `AFM_RESET_TTL_MINUTES` | Reset link lifetime (default 30). |
| `AFM_VERIFY_TTL_HOURS` | Verification link lifetime (default 48). |
| `AFM_PBKDF2_ITERATIONS` | Password hashing work factor (default 1500). |
| `AFM_MAX_LOGIN_ATTEMPTS` | Failures before throttling (default 5). |
| `AFM_MAX_RESET_REQUESTS` | Reset emails per hour (default 3). |
| `AFM_MAX_FAVORITES` | Favourites per user (default 200). |
| `AFM_ACCOUNT_PAGE_URL` | Override the email link target. |
| `AFM_DEBUG` | `true` enables server-side diagnostic logs. |

---

## 11. Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `Script function not found: doPost` | Deployment predates `Code.gs`, or you deployed a version without it | Save, then deploy a **new version** of the web app. |
| Browser shows a Google sign-in page | “Who has access” is not **Anyone** | Edit the deployment and set access to **Anyone**. |
| `NOT_CONFIGURED` toast | `API_URL` is still the placeholder | Paste the `/exec` URL in `js/config.js`. |
| `Failed to fetch` / CORS error | Wrong URL, a `/dev` URL, or the deployment is private | Use the `/exec` URL and public access. Do not add custom headers — the client already sends `text/plain`. |
| Emails never arrive | Quota exhausted, no authorisation, or spam filtering | Check **Executions** for `MailApp` errors, check spam, wait for the daily quota to reset, or use a Workspace account. |
| Email link opens a blank page | `ACCOUNT_PAGE_URL` points at a page that does not exist or is not public | Fix the URL in `Configuration.gs`, deploy a new version. |
| “This link is not valid” immediately | The email client pre-opened the link twice, or the token expired | Request a new email. Verification uses a confirmation button so scanners are not usually the cause. |
| Panel opens off-screen | The header uses `transform`/`filter` on an ancestor, changing the fixed-position containing block | Remove the transform from the sticky header, or position the panel inside that ancestor. |
| Button unstyled | `account.css` failed to load | Check the Network tab; make sure the host serves CSS with `text/css`. |
| Popup opens every page load | `sessionStorage` is blocked (private mode / cookie banner) | Expected fallback: the panel cannot remember dismissal. Users can turn it off in Account Settings. |
| Login works but reload signs out | “Remember me” unchecked (by design) or cookies blocked | Use Remember me, or allow first-party cookies for the site. |
| `SERVER_ERROR` with a reference | An unexpected backend exception | Open **Executions** in Apps Script, find the reference in the log, fix the cause. |

---

## 12. Security limitations — read before launch

This system is a careful implementation of what Apps Script can actually do.
It is **not** equivalent to a dedicated auth platform. Be aware of the following.

### No HttpOnly cookies

Apps Script web apps cannot set response headers, so they cannot create
`HttpOnly` or `Set-Cookie` cookies. The system therefore uses an **opaque
bearer token** sent in the request body:

- Normal sessions: token in `sessionStorage` (cleared when the tab closes).
- Remember me: token in a `Secure; SameSite=Lax` cookie, readable by JavaScript
  because `HttpOnly` is impossible.

Consequence: any cross-site scripting (XSS) on the site can read the token.
Mitigate by keeping the Blogger theme and third-party widgets free of untrusted
scripts, and by treating the token as a session credential, not a password.

### Token hashing, not token encryption

The Sessions sheet stores only a SHA-256 hash of each token. A stolen spreadsheet
copy does not let an attacker impersonate users, but a stolen live token does.
Tokens are revoked on logout, password change and password reset.

### PBKDF2 work factor is low by web standards

Apps Script has no native PBKDF2, scrypt or Argon2. This implementation builds
PBKDF2-HMAC-SHA256 from `Utilities.computeHmacSha256Signature`, and every
iteration is a remote call. The default is **1,500 iterations**, which takes
roughly 1–3 seconds per login. Browser-grade recommendations are 600,000
iterations; that is not achievable inside Apps Script’s execution limit.

If your threat model requires stronger hashing, move authentication to a
platform with native `crypto` (for example Cloudflare Workers, which is not an
auth vendor, or a small VPS). Raising `AFM_PBKDF2_ITERATIONS` improves resistance
but risks timeouts.

### Rate limiting is per email + device, not per IP

Apps Script does not expose the client IP address. Throttling uses
`CacheService` keys built from the submitted email and a random device ID stored
in the browser. An attacker who clears storage or rotates emails can evade it.
For serious abuse protection, put Cloudflare in front of the site and use its
rate-limiting/WAF rules. (That is infrastructure, not a third-party auth
platform.)

### Email deliverability

Mail is sent by the Google account that owns the script. You cannot configure
SPF/DKIM/DMARC for `affimarts.com` through Apps Script. Some recipients may see
“via googlemail.com” or land in spam. For production volume, use a transactional
email provider and change `afmSendMail_` in `EmailService.gs`.

### The web-app URL is public

Anyone who knows the `/exec` URL can call public actions (register, login,
request reset). That is normal for an auth API. Protected actions always require
a valid session token; the server never trusts a user ID supplied by the client.
`initializeDatabase` is disabled unless you explicitly set `AFM_SETUP_KEY`.

### Spreadsheet access

Anyone with edit access to the spreadsheet can read password hashes and session
hashes. Limit sharing to the owning account and trusted admins. Do not publish
the sheet.

### What is protected

- Passwords: salted PBKDF2 hashes, never plaintext, never returned by the API.
- Sessions: random 256-bit tokens, hashes only in the sheet, server-side expiry
  and revocation.
- Verification/reset: single-use tokens, hashes only in the sheet, expiring
  (48h / 30min), generic responses that do not reveal whether an email exists.
- Authorisation: every profile/favourite operation resolves the user from the
  session token, never from a frontend-supplied user ID.
- Input: normalised emails, trimmed/length-limited text, HTML escaping in email,
  `textContent` (not `innerHTML`) for user data in the dashboard.
- Locking: targeted `LockService` sections around duplicate checks, token
  consumption, favourites and session creation.

### Recommended additional hardening

1. Serve the site over HTTPS only (GitHub Pages/Cloudflare do this).
2. Add a Content-Security-Policy that allows only your own scripts, Google
   Fonts/images you actually use, and the Apps Script endpoint.
3. Put Cloudflare (or similar) in front of `affimarts.com` for IP-based rate
   limiting and bot mitigation.
4. Review Blogger gadgets and third-party scripts quarterly.
5. Keep the owning Google account protected with 2-Step Verification.
6. Back up the spreadsheet and restrict its sharing.

---

## 13. Rollback

- **Frontend:** restore `New Mega Menu.original.html` over `New Mega Menu.html`,
  or revert the commit on your host.
- **Backend:** in **Manage deployments**, edit the deployment and select the
  previous version. No data is lost.
- **Data:** restore a spreadsheet copy, or use **File → Version history**.

---

## 14. File map

```
D:\HTML PAGE\
├── New Mega Menu.html                 ← updated mega menu (MY ACCOUNT)
├── New Mega Menu.original.html        ← untouched original
└── affimarts-account\
    ├── index.html                     ← account page (guest + dashboard)
    ├── DEPLOYMENT.md                  ← this guide
    ├── README.md                      ← overview and API reference
    ├── css\
    │   └── account.css
    ├── js\
    │   ├── config.js                  ← the only file you must edit
    │   ├── validation.js
    │   ├── session.js
    │   ├── authentication.js
    │   ├── profile.js
    │   ├── favorites.js
    │   └── account.js
    ├── google-apps-script\
    │   ├── Configuration.gs
    │   ├── Security.gs
    │   ├── Database.gs
    │   ├── Sessions.gs
    │   ├── EmailService.gs
    │   ├── Authentication.gs
    │   ├── Profile.gs
    │   ├── Favorites.gs
    │   └── Code.gs
    └── tests\
        ├── backend.test.js
        └── frontend.test.js
```

---

## 15. Support checklist for the developer

When something fails in production, collect:

1. The exact toast/message and any `reference` code.
2. Browser console output (never paste tokens).
3. Apps Script **Executions** log for the matching time.
4. The spreadsheet tab and row involved (redact hashes).
5. Whether the user was signed in, and whether “Remember me” was used.

Do not ask users to send passwords, verification tokens or reset tokens.

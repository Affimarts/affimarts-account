# Affimarts Account

A complete, self-hosted account system for **Affimarts** built with HTML, CSS,
vanilla JavaScript, Google Apps Script and Google Sheets. No Firebase, Supabase,
WordPress auth or third-party identity platform.

The mega menu’s **TRENDING** button has been replaced, in the same position, by a
**MY ACCOUNT** button that opens a premium sign-in panel. The panel becomes a
centred modal on mobile and opens automatically three seconds after load for
signed-out visitors (once per tab).

```
D:\HTML PAGE\
├── New Mega Menu.html                 ← updated mega menu
├── New Mega Menu.original.html        ← untouched original
└── affimarts-account\
    ├── index.html                     ← account page / dashboard
    ├── DEPLOYMENT.md                  ← step-by-step go-live guide
    ├── README.md                      ← this file
    ├── css/account.css
    ├── js/
    │   ├── config.js                  ← the only file you must edit
    │   ├── validation.js
    │   ├── session.js
    │   ├── authentication.js
    │   ├── profile.js
    │   ├── favorites.js
    │   └── account.js
    ├── google-apps-script/
    │   ├── Configuration.gs
    │   ├── Security.gs
    │   ├── Database.gs
    │   ├── Sessions.gs
    │   ├── EmailService.gs
    │   ├── Authentication.gs
    │   ├── Profile.gs
    │   ├── Favorites.gs
    │   └── Code.gs
    └── tests/
        ├── backend.test.js
        └── frontend.test.js
```

---

## Quick start

1. Follow **`DEPLOYMENT.md`** sections 1–3 to create the Apps Script project,
   run `initializeDatabase()` and deploy the web app.
2. Put the `/exec` URL in `js/config.js`.
3. Host `index.html`, `css/` and `js/` (GitHub Pages, Cloudflare Pages, Netlify,
   or inline in Blogger).
4. Point the mega menu’s `<link>` and `<script>` tags at the hosted files.
5. Set `ACCOUNT_PAGE_URL` in `Configuration.gs` to the published account page,
   then deploy a new version.
6. Run the checklist in `DEPLOYMENT.md` section 8.

The supplied spreadsheet is already configured:

```
1wzIcUZPb4gGltN5TxAKYQIGWwObCkRdEuOIKHLWRqT4
```

---

## Features

### Account button and popup

- Replaces TRENDING without moving it; all other mega menu behaviour is intact.
- Desktop: panel anchored under the button, slide-down + fade-in.
- Mobile (≤1020px): centred modal with a dimmed backdrop and focus trap.
- Closes on ×, Escape, outside click or backdrop click.
- Automatic prompt exactly 3 seconds after load, once per tab
  (`sessionStorage`), never for signed-in users, and suppressible per device.
- Header button becomes the user’s first name with a gold initials avatar.
- Signed-in panel: My Profile, Edit Profile, My Favorites, Account Settings,
  Logout.

### Registration

- Required: full name, email, password, confirm password.
- Optional: mobile, gender, date of birth.
- Client and server validation (name characters, email shape, phone digits,
  age ≥ 13, password policy, confirmation).
- Case-insensitive duplicate prevention with a lock around the check.
- Unique IDs in the form `AFM-YYYYMMDD-XXXXXXXX`.
- Passwords stored as `pbkdf2_sha256$iterations$salt$hash`; never plaintext.
- Email verification is required before login; the account is not marked
  verified until the confirmation button is pressed.
- Single-use, hashed, 48-hour verification tokens; resend is rate-limited and
  always gives a generic response.

### Login and sessions

- Show/hide password, remember me, forgot password.
- Structured error codes and messages; unknown emails and wrong passwords are
  indistinguishable.
- Throttling: 5 failures per email + device per 15 minutes.
- 256-bit opaque session tokens; only SHA-256 hashes stored in the sheet.
- Normal session 2 hours; “Remember me” 30 days.
- Server-side expiry, revocation on logout, password change and reset.
- Token storage: `sessionStorage` normally; `Secure; SameSite=Lax` cookie for
  remember me. Apps Script cannot set `HttpOnly`, which is documented honestly
  in `DEPLOYMENT.md`.

### Password reset

- 30-minute expiry, single use, token hash only.
- Generic response for known and unknown emails.
- All sessions revoked after a successful reset.
- Branded email sent with `MailApp` (GmailApp fallback).

### Dashboard

- **My Profile** — name, email, verification status, mobile, date of birth,
  gender, member since, last login, favourites count.
- **Edit Profile** — validated updates; email change is intentionally routed
  through support so it can be re-verified.
- **My Favorites** — image (or letter tile), title, View product, Remove, plus a
  manual “Save a product link” form.
- **Account Settings** — change password, sign out of all devices, logout,
  sign-in prompt and reduced-motion preferences.

### Product save buttons

Any element with `data-afm-save` becomes a favourite button:

```html
<button type="button" data-afm-save
        data-afm-title="Product name"
        data-afm-url="https://www.affimarts.com/..."
        data-afm-image="https://...">
  <span data-afm-save-label>Save</span>
</button>
```

Signed-out clicks open the sign-in panel. Call
`AFM.favorites.bindSaveButtons(container)` after adding cards dynamically.

---

## API reference

All operations are `POST` to the `/exec` URL with
`Content-Type: text/plain;charset=utf-8` (a CORS “simple request”, so no
preflight that Apps Script cannot answer).

Request:

```json
{
  "action": "loginUser",
  "token": "",
  "data": { "email": "you@example.com", "password": "…", "remember": true },
  "meta": { "deviceId": "…" }
}
```

Response:

```json
{ "success": true, "code": "OK", "message": "…", "data": { } }
```

Failures use `success: false` with a machine-readable `code`
(`INVALID_CREDENTIALS`, `EMAIL_NOT_VERIFIED`, `TOKEN_EXPIRED`,
`TOO_MANY_REQUESTS`, …) and a safe user-facing `message`.

| Action | Auth | Purpose |
| --- | --- | --- |
| `health` | public | Status and API version |
| `initializeDatabase` | setup key | Create sheets/headers |
| `registerUser` | public | Create an unverified account |
| `loginUser` | public | Issue a session token |
| `verifyEmail` | public | Consume a verification token |
| `resendVerificationEmail` | public | Send a fresh verification link |
| `requestPasswordReset` | public | Send a reset link (generic response) |
| `resetPassword` | public | Consume a reset token, revoke sessions |
| `validateSession` | token | Return user + session metadata |
| `logoutUser` | token | Revoke the current session |
| `logoutAll` | token | Revoke every session for the user |
| `getUserProfile` | token | Profile + favourite count |
| `updateUserProfile` | token | Update name, mobile, gender, DOB |
| `updatePassword` | token | Verify current password, revoke others |
| `getFavorites` | token | List the user’s favourites |
| `addFavorite` | token | Add/de-duplicate a favourite |
| `removeFavorite` | token | Remove one owned favourite |

Protected actions resolve the user from the session token. A user ID sent by the
browser is never trusted.

### `GET` endpoints

- `?action=health` — JSON health check.
- `?action=verify&token=…` — branded confirmation page (button prevents link
  scanners from burning the token).
- `?action=reset&token=…` — branded page linking to the account reset view.
- anything else — a short info page.

---

## Data model

| Sheet | Columns |
| --- | --- |
| **Users** | User ID, Full Name, Email, Password Hash, Password Salt, Mobile Number, Gender, Date of Birth, Registration Date, Account Status, Email Verified, Last Login, Updated At |
| **Sessions** | Session ID, User ID, Session Token Hash, Created At, Expires At, Revoked |
| **PasswordReset** | User ID, Reset Token Hash, Created At, Expires At, Used |
| **EmailVerification** | User ID, Verification Token Hash, Created At, Expires At, Used |
| **Favorites** | Favorite ID, User ID, Product Title, Product URL, Image URL, Added At |

- Emails are trimmed and lowercased before storage and lookup.
- Password and session columns never contain raw credentials.
- Expired sessions are pruned opportunistically; revoked sessions are ignored
  immediately.
- Set `Account Status` to `disabled` to block an account.

---

## Configuration

`js/config.js`:

| Key | Default | Meaning |
| --- | --- | --- |
| `API_URL` | placeholder | Apps Script `/exec` URL |
| `ACCOUNT_PAGE` | `/p/my-account.html` | Dashboard page URL |
| `SITE_URL` | `https://www.affimarts.com` | Storefront home |
| `AUTO_POPUP` | `true` | Enable the 3-second prompt |
| `POPUP_DELAY_MS` | `3000` | Prompt delay |
| `REQUEST_TIMEOUT_MS` | `30000` | Client timeout |
| `DEBUG` | `false` | Timing logs only |

Backend values live in `Configuration.gs` and can be overridden with
`AFM_<KEY>` Script Properties (session TTL, token TTLs, PBKDF2 iterations,
throttle limits, favourites limit, email link target, debug). See
`DEPLOYMENT.md` section 10.

---

## Design

The account UI mirrors the Affimarts palette and typography already used by the
mega menu:

- Wine `#6D1837`, deep wine `#4D0F26`, pale wine `#F4E8EC`
- Gold `#B58A48`, soft gold `#E6D5B6`
- Cream `#F7F3EE`, paper `#FFFDF9`, ink `#171717`
- Serif display type, uppercase sans labels with wide tracking

Everything is scoped under `.afm-*` and CSS custom properties, so it does not
alter unrelated theme elements. Layouts are tested from 360px to 1440px with no
horizontal overflow, 44px+ touch targets, visible focus states, reduced-motion
support and a mobile modal focus trap.

---

## Tests

The test suites run on Node 18+ with no dependencies. They execute the real
`.gs` files inside a `vm` sandbox with in-memory Google services, and the real
frontend modules inside a fake browser.

```powershell
node "D:\HTML PAGE\affimarts-account\tests\backend.test.js"
node "D:\HTML PAGE\affimarts-account\tests\frontend.test.js"
```

Backend coverage (36 checks):

- spreadsheet ID, sheet creation, exact headers, locked remote setup
- PBKDF2 vector against Node’s reference implementation
- hash format, salting, verification, weak/common/name passwords
- registration, normalisation, duplicate prevention, validation
- verification single-use, login gating, generic resend
- sessions, token hashes, expiry, remember-me TTL, revocation
- profile load/update, password change, session invalidation
- favourites add/list/de-duplicate/ownership/remove
- reset generic response, single use, expiry, session revocation
- login throttling, logout, logout-all
- transport errors, malformed JSON, secret-free health check

Frontend coverage (23 checks):

- email, name, phone, date-of-birth, password, confirmation and URL validators
- password strength and context checks
- sessionStorage vs remember-me cookie behaviour, clearing, cached-user
  sanitisation, stable device ID
- API configuration detection, `text/plain` POST body, bearer token, device ID,
  server error mapping, session-expiry event, non-JSON response handling

The suites do not cover real email delivery, Apps Script quotas, or pixel-level
rendering. Those are covered by the live checklist in `DEPLOYMENT.md`.

---

## Security summary

- Salted PBKDF2-HMAC-SHA256 password hashes; plaintext never stored or returned.
- Random 256-bit session tokens; only hashes in the sheet; server-side expiry
  and revocation.
- Single-use, hashed, expiring verification and reset tokens.
- Generic responses for account enumeration-sensitive endpoints.
- Server-side authorisation from the session, never from client-supplied IDs.
- Targeted `LockService` sections for duplicate checks, token consumption,
  favourites and session creation.
- Input trimming/length limits, email normalisation, HTML escaping in email,
  `textContent` for user data in the DOM.
- `initializeDatabase` API disabled unless `AFM_SETUP_KEY` is set.

Known limitations, explained fully in `DEPLOYMENT.md` section 12:

- Apps Script cannot set `HttpOnly` cookies, so bearer tokens are readable by
  JavaScript. Strong XSS hygiene and a CSP are essential.
- PBKDF2 is limited to 1,500 iterations by Apps Script latency.
- Throttling is per email + device because Apps Script exposes no client IP.
- MailApp has a daily recipient quota and no control over SPF/DKIM.
- Anyone with the `/exec` URL can call public auth actions (normal for an API).
- Spreadsheet editors can read hashes; restrict sharing.

For higher assurance, terminate the frontend at Cloudflare for WAF/rate limiting
and move password hashing to a runtime with native crypto if your threat model
requires a browser-grade work factor.

---

## Browser support

Modern evergreen browsers (Chrome, Edge, Firefox, Safari) on desktop and mobile.
The code uses `fetch`, `Promise`, `Element.closest`, CSS custom properties and
`aspect-ratio`; no build step or polyfill bundle is required.

---

## Licence and ownership

Built for Affimarts. Review the security limitations and complete the live
checklist before accepting real user accounts.

/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — AUTHENTICATION
 * ============================================================================
 * Registration, sign-in, email verification, password recovery and logout.
 *
 * Design notes:
 *   • Passwords are hashed with PBKDF2-HMAC-SHA256 + a unique 128-bit salt.
 *   • Verification / reset tokens are random, single-use, expiring, and only
 *     their SHA-256 hash is stored.
 *   • Sessions are server-side; the browser receives an opaque bearer token.
 *   • Account status and email verification are always re-checked server-side.
 * ============================================================================
 */

/* ========================================================================== */
/*  Registration                                                              */
/* ========================================================================== */

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function registerUser(data, context) {
  data = data || {};
  var meta = (context && context.meta) || {};

  var fullName = afmCleanText_(data.fullName, afmConfig_('MAX_NAME_LENGTH') || 80);
  var email = afmNormalizeEmail_(data.email);
  var password = String(data.password == null ? '' : data.password);
  var confirm = String(data.confirmPassword == null ? '' : data.confirmPassword);
  var mobile = afmCleanText_(data.mobile, 24);
  var gender = afmNormalizeGender_(data.gender);
  var dob = afmCleanText_(data.dob, 10);

  var nameProblem = afmNameProblem_(fullName);
  if (nameProblem) afmFail_('INVALID_NAME', nameProblem);

  if (!afmIsValidEmail_(email)) {
    afmFail_('INVALID_EMAIL', 'Enter a valid email address, for example name@example.com.');
  }

  var passwordProblem = afmPasswordProblem_(password, { email: email, fullName: fullName });
  if (passwordProblem) afmFail_('WEAK_PASSWORD', passwordProblem);

  if (password !== confirm) {
    afmFail_('PASSWORD_MISMATCH', 'The two passwords do not match.');
  }

  var phoneProblem = afmPhoneProblem_(mobile);
  if (phoneProblem) afmFail_('INVALID_PHONE', phoneProblem);

  var dobProblem = afmDobProblem_(dob);
  if (dobProblem) afmFail_('INVALID_DOB', dobProblem);

  var deviceId = afmSafeDeviceId_(meta.deviceId);
  afmRateLimit_(
    'register-device', deviceId,
    Number(afmConfig_('MAX_REGISTRATIONS_PER_DEVICE')) || 5,
    Number(afmConfig_('REGISTRATION_WINDOW_SECONDS')) || 3600,
    'Too many accounts were created from this device. Please try again later.'
  );
  afmRateLimit_(
    'register-email', email,
    3,
    Number(afmConfig_('REGISTRATION_WINDOW_SECONDS')) || 3600,
    'Too many registration attempts. Please try again later.'
  );

  /* Hash before taking the lock: PBKDF2 is the slow part. */
  var passwordRecord = afmHashPassword_(password);

  var created = afmWithLock_(function () {
    if (afmFindUserByEmail_(email)) {
      afmFail_('EMAIL_EXISTS', 'An account with this email already exists. Try signing in instead.');
    }

    var userId = afmGenerateUserId_();
    var now = new Date().toISOString();

    afmInsertUser_({
      userId: userId,
      fullName: fullName,
      email: email,
      passwordHash: passwordRecord.hash,
      passwordSalt: passwordRecord.salt,
      mobile: mobile,
      gender: gender,
      dob: dob,
      registrationDate: now,
      status: 'active',
      emailVerified: false,
      lastLogin: '',
      updatedAt: now
    });

    return { userId: userId, now: now };
  });

  /* Email verification: issue the token, then send outside the lock. */
  var token = afmIssueVerificationToken_(created.userId);
  var delivery = afmSendVerificationEmail_(
    { email: email, fullName: fullName },
    token
  );

  return {
    message: delivery.sent
      ? 'Your account was created. Check your inbox to confirm your email address.'
      : 'Your account was created, but we could not send the verification email. Use "Resend verification email" to try again.',
    data: {
      userId: created.userId,
      email: email,
      emailVerified: false,
      verificationEmailSent: delivery.sent
    }
  };
}

/* ========================================================================== */
/*  Sign in                                                                   */
/* ========================================================================== */

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function loginUser(data, context) {
  data = data || {};
  var meta = (context && context.meta) || {};

  var email = afmNormalizeEmail_(data.email);
  var password = String(data.password == null ? '' : data.password);
  var remember = data.remember === true || data.remember === 'true';
  var deviceId = afmSafeDeviceId_(meta.deviceId);

  if (!email || !password) {
    afmFail_('INVALID_CREDENTIALS', 'Enter your email address and password.');
  }

  var maxAttempts = Number(afmConfig_('MAX_LOGIN_ATTEMPTS')) || 5;
  var windowSeconds = Number(afmConfig_('LOGIN_WINDOW_SECONDS')) || 900;

  afmRateLimit_(
    'login-email', email, maxAttempts, windowSeconds,
    'Too many sign-in attempts for this email. Please wait 15 minutes and try again.'
  );
  afmRateLimit_(
    'login-device', deviceId, maxAttempts * 4, windowSeconds,
    'Too many sign-in attempts from this device. Please wait a few minutes.'
  );

  var found = afmFindUserByEmail_(email);

  if (!found) {
    /* Equalise timing with a real verification so emails cannot be probed. */
    try {
      afmHashPassword_(password);
    } catch (err) {
      /* ignore */
    }
    afmFail_('INVALID_CREDENTIALS', 'The email or password you entered is incorrect.');
  }

  var user = found.user;
  var valid = afmVerifyPassword_(password, user.passwordHash, user.passwordSalt);

  if (!valid) {
    afmFail_('INVALID_CREDENTIALS', 'The email or password you entered is incorrect.');
  }

  if (user.status !== 'active') {
    afmFail_('ACCOUNT_DISABLED', 'This account is disabled. Please contact support.');
  }

  if (!user.emailVerified) {
    afmFail_(
      'EMAIL_NOT_VERIFIED',
      'Please confirm your email address before signing in. Check your inbox for the verification link.'
    );
  }

  var session = afmCreateSession_(user.userId, remember);

  afmUpdateUser_(found.rowIndex, {
    lastLogin: new Date().toISOString()
  });

  afmRateClear_('login-email', email);
  afmRateClear_('login-device', deviceId);

  return {
    message: 'Signed in successfully.',
    data: {
      token: session.token,
      expiresAt: session.expiresAt,
      remember: session.remember,
      user: afmPublicUser_(user)
    }
  };
}

/* ========================================================================== */
/*  Session helpers exposed to the API                                        */
/* ========================================================================== */

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function validateSession(data, context) {
  var auth = afmAuthFromContext_(context);
  return {
    message: 'Session is valid.',
    data: {
      user: afmPublicUser_(auth.user),
      session: {
        sessionId: auth.session.sessionId,
        createdAt: auth.session.createdAt,
        expiresAt: auth.session.expiresAt
      }
    }
  };
}

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function logoutUser(data, context) {
  afmRevokeSessionByToken_(context.token);
  return { message: 'You have been signed out.', data: { signedOut: true } };
}

/**
 * Sign out every device for the authenticated user.
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function logoutAll(data, context) {
  var auth = afmAuthFromContext_(context);
  var revoked = afmRevokeAllSessions_(auth.user.userId, null);
  return {
    message: 'All devices have been signed out.',
    data: { revokedSessions: revoked }
  };
}

/* ========================================================================== */
/*  Email verification                                                        */
/* ========================================================================== */

/**
 * Issue (and persist) a fresh verification token for a user.
 * Invalidates any previous unused tokens.
 * @param {string} userId
 * @return {string} raw token
 */
function afmIssueVerificationToken_(userId) {
  var token = afmRandomToken_(32);
  var hash = afmHashToken_(token);
  var now = new Date();
  var expires = new Date(now.getTime() + (Number(afmConfig_('VERIFY_TTL_HOURS')) || 48) * 60 * 60 * 1000);

  afmWithLock_(function () {
    var table = afmTable_('EmailVerification');
    for (var i = 0; i < table.rows.length; i++) {
      if (String(table.rows[i][0]) !== String(userId)) continue;
      if (!afmToBool_(table.rows[i][4])) {
        afmUpdateRow_('EmailVerification', i + 2, { Used: true });
      }
    }
    afmAppendRow_('EmailVerification', [
      userId, hash, now.toISOString(), expires.toISOString(), false
    ]);
  });

  return token;
}

/**
 * Consume a verification token.
 * @param {Object} data
 * @return {{message: string, data: Object}}
 */
function verifyEmail(data) {
  data = data || {};
  var token = String(data.token || '');
  if (!token) afmFail_('TOKEN_INVALID', 'This verification link is incomplete.');

  var hash = afmHashToken_(token);

  var result = afmWithLock_(function () {
    var table = afmTable_('EmailVerification');
    var match = null;

    for (var i = 0; i < table.rows.length; i++) {
      if (String(table.rows[i][1]) !== hash) continue;
      match = {
        rowIndex: i + 2,
        userId: String(table.rows[i][0] || ''),
        expiresAt: afmToIso_(table.rows[i][3]),
        used: afmToBool_(table.rows[i][4])
      };
      break;
    }

    if (!match) {
      afmFail_('TOKEN_INVALID', 'This verification link is not valid. Request a new one from the sign-in screen.');
    }
    if (match.used) {
      afmFail_('TOKEN_USED', 'This verification link has already been used. You can sign in normally.');
    }
    if (new Date(match.expiresAt).getTime() <= Date.now()) {
      afmUpdateRow_('EmailVerification', match.rowIndex, { Used: true });
      afmFail_('TOKEN_EXPIRED', 'This verification link has expired. Request a new one from the sign-in screen.');
    }

    var found = afmFindUserById_(match.userId);
    if (!found) afmFail_('TOKEN_INVALID', 'This verification link is no longer valid.');

    afmUpdateRow_('EmailVerification', match.rowIndex, { Used: true });
    afmUpdateUser_(found.rowIndex, {
      emailVerified: true,
      status: found.user.status === 'disabled' ? 'disabled' : 'active'
    });

    return found.user;
  });

  return {
    message: 'Your email address is confirmed. You can now sign in.',
    data: {
      email: result.email,
      emailVerified: true
    }
  };
}

/**
 * Resend a verification email. Always returns a generic response.
 * @param {Object} data
 * @return {{message: string, data: Object}}
 */
function resendVerificationEmail(data) {
  data = data || {};
  var email = afmNormalizeEmail_(data.email);
  var generic = 'If this address needs confirmation, a new verification email is on its way.';

  if (!afmIsValidEmail_(email)) {
    afmFail_('INVALID_EMAIL', 'Enter a valid email address.');
  }

  afmRateLimit_(
    'resend-verify', email,
    Number(afmConfig_('MAX_VERIFY_RESENDS')) || 3,
    Number(afmConfig_('VERIFY_RESEND_WINDOW_SECONDS')) || 3600,
    'A verification email was already sent recently. Please check your inbox and spam folder.'
  );

  var found = afmFindUserByEmail_(email);
  if (!found || found.user.emailVerified) {
    return { message: generic, data: { sent: true } };
  }

  var token = afmIssueVerificationToken_(found.user.userId);
  var delivery = afmSendVerificationEmail_(found.user, token);

  return {
    message: generic,
    data: { sent: delivery.sent }
  };
}

/* ========================================================================== */
/*  Password recovery                                                         */
/* ========================================================================== */

/**
 * Issue (and persist) a password reset token. Invalidates previous ones.
 * @param {string} userId
 * @return {string} raw token
 */
function afmIssueResetToken_(userId) {
  var token = afmRandomToken_(32);
  var hash = afmHashToken_(token);
  var now = new Date();
  var expires = new Date(now.getTime() + (Number(afmConfig_('RESET_TTL_MINUTES')) || 30) * 60 * 1000);

  afmWithLock_(function () {
    var table = afmTable_('PasswordReset');
    for (var i = 0; i < table.rows.length; i++) {
      if (String(table.rows[i][0]) !== String(userId)) continue;
      if (!afmToBool_(table.rows[i][4])) {
        afmUpdateRow_('PasswordReset', i + 2, { Used: true });
      }
    }
    afmAppendRow_('PasswordReset', [
      userId, hash, now.toISOString(), expires.toISOString(), false
    ]);
  });

  return token;
}

/**
 * Request a password reset. The response never reveals whether the email is
 * registered.
 * @param {Object} data
 * @return {{message: string, data: Object}}
 */
function requestPasswordReset(data) {
  data = data || {};
  var email = afmNormalizeEmail_(data.email);
  var generic = 'If an Affimarts account exists for that email, a password reset link is on its way. The link expires in 30 minutes.';

  if (!afmIsValidEmail_(email)) {
    afmFail_('INVALID_EMAIL', 'Enter the email address linked to your account.');
  }

  afmRateLimit_(
    'password-reset', email,
    Number(afmConfig_('MAX_RESET_REQUESTS')) || 3,
    Number(afmConfig_('RESET_WINDOW_SECONDS')) || 3600,
    'A reset email was requested recently. Please check your inbox and spam folder.'
  );

  var found = afmFindUserByEmail_(email);
  if (!found || found.user.status === 'disabled') {
    return { message: generic, data: { sent: true } };
  }

  var token = afmIssueResetToken_(found.user.userId);
  afmSendPasswordResetEmail_(found.user, token);

  return { message: generic, data: { sent: true } };
}

/**
 * Complete a password reset with a single-use token.
 * @param {Object} data
 * @return {{message: string, data: Object}}
 */
function resetPassword(data) {
  data = data || {};
  var token = String(data.token || '');
  var password = String(data.password == null ? '' : data.password);
  var confirm = String(data.confirmPassword == null ? '' : data.confirmPassword);

  if (!token) afmFail_('TOKEN_INVALID', 'This reset link is incomplete.');

  var hash = afmHashToken_(token);
  var table = afmTable_('PasswordReset');
  var match = null;

  for (var i = 0; i < table.rows.length; i++) {
    if (String(table.rows[i][1]) !== hash) continue;
    match = {
      rowIndex: i + 2,
      userId: String(table.rows[i][0] || ''),
      expiresAt: afmToIso_(table.rows[i][3]),
      used: afmToBool_(table.rows[i][4])
    };
    break;
  }

  if (!match) {
    afmFail_('TOKEN_INVALID', 'This password reset link is not valid. Request a new one.');
  }
  if (match.used) {
    afmFail_('TOKEN_USED', 'This reset link has already been used. Request a new one if needed.');
  }
  if (new Date(match.expiresAt).getTime() <= Date.now()) {
    afmFail_('TOKEN_EXPIRED', 'This reset link has expired. Request a new one.');
  }

  var found = afmFindUserById_(match.userId);
  if (!found) afmFail_('TOKEN_INVALID', 'This reset link is no longer valid.');

  var problem = afmPasswordProblem_(password, {
    email: found.user.email,
    fullName: found.user.fullName
  });
  if (problem) afmFail_('WEAK_PASSWORD', problem);

  if (password !== confirm) {
    afmFail_('PASSWORD_MISMATCH', 'The two passwords do not match.');
  }

  if (afmVerifyPassword_(password, found.user.passwordHash, found.user.passwordSalt)) {
    afmFail_('PASSWORD_UNCHANGED', 'Choose a password you have not used before.');
  }

  var passwordRecord = afmHashPassword_(password);

  afmWithLock_(function () {
    /* Re-read the token inside the lock so it can only be consumed once. */
    var fresh = afmTable_('PasswordReset');
    var row = null;
    for (var j = 0; j < fresh.rows.length; j++) {
      if (String(fresh.rows[j][1]) !== hash) continue;
      row = { rowIndex: j + 2, used: afmToBool_(fresh.rows[j][4]) };
      break;
    }
    if (!row || row.used) {
      afmFail_('TOKEN_USED', 'This reset link has already been used. Request a new one.');
    }

    afmUpdateRow_('PasswordReset', row.rowIndex, { Used: true });
    afmUpdateUser_(found.rowIndex, {
      passwordHash: passwordRecord.hash,
      passwordSalt: passwordRecord.salt
    });
    afmRevokeAllSessions_(found.user.userId, null);
  });

  return {
    message: 'Your password has been updated. Sign in with your new password.',
    data: { email: found.user.email }
  };
}

/* ========================================================================== */
/*  Authenticated password change                                             */
/* ========================================================================== */

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function updatePassword(data, context) {
  data = data || {};
  var auth = afmAuthFromContext_(context);
  var current = String(data.currentPassword == null ? '' : data.currentPassword);
  var password = String(data.newPassword == null ? '' : data.newPassword);
  var confirm = String(data.confirmPassword == null ? '' : data.confirmPassword);

  if (!afmVerifyPassword_(current, auth.user.passwordHash, auth.user.passwordSalt)) {
    afmFail_('INVALID_PASSWORD', 'Your current password is incorrect.');
  }

  var problem = afmPasswordProblem_(password, {
    email: auth.user.email,
    fullName: auth.user.fullName
  });
  if (problem) afmFail_('WEAK_PASSWORD', problem);

  if (password !== confirm) {
    afmFail_('PASSWORD_MISMATCH', 'The two passwords do not match.');
  }

  if (afmVerifyPassword_(password, auth.user.passwordHash, auth.user.passwordSalt)) {
    afmFail_('PASSWORD_UNCHANGED', 'Your new password must be different from your current one.');
  }

  var record = afmHashPassword_(password);

  afmWithLock_(function () {
    afmUpdateUser_(auth.rowIndex, {
      passwordHash: record.hash,
      passwordSalt: record.salt
    });
    /* Keep the current device signed in, revoke everything else. */
    afmRevokeAllSessions_(auth.user.userId, afmHashToken_(context.token));
  });

  return {
    message: 'Your password has been changed. Other devices have been signed out.',
    data: { updated: true }
  };
}

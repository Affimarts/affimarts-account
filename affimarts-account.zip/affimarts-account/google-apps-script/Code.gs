/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — API ENTRY POINT
 * ============================================================================
 * Deploy this project as a web app:
 *   Execute as: Me
 *   Who has access: Anyone
 *
 * Transport contract
 * ------------------
 * POST  <deployment-url>
 * Content-Type: text/plain;charset=utf-8      (a "simple" request: no CORS
 *                                              preflight, which Apps Script
 *                                              cannot answer)
 * Body: { "action": "...", "token": "...", "data": {...}, "meta": {...} }
 *
 * Response: { "success": true|false, "code": "...", "message": "...",
 *             "data": { ... } }
 *
 * Apps Script cannot set HTTP response headers, so no CORS or Set-Cookie
 * headers are produced by this project. That is why authentication uses an
 * explicit bearer token in the body instead of cookies (see DEPLOYMENT.md).
 * ============================================================================
 */

/* ========================================================================== */
/*  Route table                                                               */
/* ========================================================================== */

var AFM_ROUTES = {
  /* Public */
  'health':                { handler: afmHandleHealth_,        isPublic: true },
  'registerUser':          { handler: registerUser,            isPublic: true },
  'loginUser':             { handler: loginUser,               isPublic: true },
  'verifyEmail':           { handler: verifyEmail,             isPublic: true },
  'resendVerificationEmail': { handler: resendVerificationEmail, isPublic: true },
  'requestPasswordReset':  { handler: requestPasswordReset,    isPublic: true },
  'resetPassword':         { handler: resetPassword,           isPublic: true },
  'initializeDatabase':    { handler: afmHandleInitialize_,    isPublic: true },

  /* Protected — require a live session token */
  'validateSession':       { handler: validateSession,         isPublic: false },
  'logoutUser':            { handler: logoutUser,              isPublic: false },
  'logoutAll':             { handler: logoutAll,               isPublic: false },
  'getUserProfile':        { handler: getUserProfile,          isPublic: false },
  'updateUserProfile':     { handler: updateUserProfile,       isPublic: false },
  'updatePassword':        { handler: updatePassword,          isPublic: false },
  'getFavorites':          { handler: getFavorites,            isPublic: false },
  'addFavorite':           { handler: addFavorite,             isPublic: false },
  'removeFavorite':        { handler: removeFavorite,          isPublic: false }
};

/* ========================================================================== */
/*  HTTP entry points                                                         */
/* ========================================================================== */

/**
 * @param {GoogleAppsScript.Events.DoPost} e
 * @return {GoogleAppsScript.Content.TextOutput}
 */
function doPost(e) {
  var response;

  try {
    var request = afmParseRequest_(e);
    response = afmDispatch_(request);
  } catch (err) {
    response = afmErrorResponse_(err);
  }

  return afmJsonOutput_(response);
}

/**
 * GET is used only for health checks and for email links that fall back to the
 * Apps Script URL. All account operations are POST.
 * @param {GoogleAppsScript.Events.DoGet} e
 * @return {GoogleAppsScript.Content.TextOutput|GoogleAppsScript.HTML.HtmlOutput}
 */
function doGet(e) {
  var params = (e && e.parameter) || {};
  var action = afmCleanText_(params.action, 40);

  if (action === 'health' || action === 'ping') {
    var health;
    try {
      health = afmDispatch_({ action: 'health', token: '', data: {}, meta: {} });
    } catch (err) {
      health = afmErrorResponse_(err);
    }
    return afmJsonOutput_(health);
  }

  if (action === 'verify' && params.token) {
    return afmRenderVerificationPage_(params.token, params.confirm === '1');
  }

  if (action === 'reset' && params.token) {
    return afmRenderResetRedirect_(params.token);
  }

  return afmRenderInfoPage_();
}

/* ========================================================================== */
/*  Dispatch                                                                  */
/* ========================================================================== */

/**
 * @param {{action: string, token: string, data: Object, meta: Object}} request
 * @return {Object} JSON-serialisable response
 */
function afmDispatch_(request) {
  var action = afmCleanText_(request.action, 60);
  var route = AFM_ROUTES[action];

  if (!route) {
    return {
      success: false,
      code: 'UNKNOWN_ACTION',
      message: 'Unknown request.',
      data: {}
    };
  }

  var context = {
    action: action,
    token: request.token || '',
    meta: request.meta || {},
    user: null,
    session: null
  };

  if (!route.isPublic) {
    var auth = afmRequireSession_(context.token);
    context.user = auth.user;
    context.session = auth.session;
    context.userRowIndex = auth.rowIndex;
  }

  var result = route.handler(request.data || {}, context) || {};

  return {
    success: true,
    code: 'OK',
    message: result.message || 'Operation completed successfully',
    data: result.data === undefined ? {} : result.data
  };
}

/**
 * Resolve the authenticated user for a protected handler. The router has
 * already validated the token; this keeps direct calls (and future routes)
 * safe as well.
 * @param {Object} context
 * @return {{user: Object, session: Object, rowIndex: number}}
 */
function afmAuthFromContext_(context) {
  if (context && context.user && context.session) {
    return {
      user: context.user,
      session: context.session,
      rowIndex: context.userRowIndex
    };
  }
  return afmRequireSession_(context && context.token);
}

/**
 * @param {GoogleAppsScript.Events.DoPost} e
 * @return {{action: string, token: string, data: Object, meta: Object}}
 */
function afmParseRequest_(e) {
  var body = null;

  if (e && e.postData && e.postData.contents) {
    try {
      body = JSON.parse(e.postData.contents);
    } catch (err) {
      afmFail_('BAD_REQUEST', 'The request body must be valid JSON.');
    }
  } else if (e && e.parameter) {
    body = {
      action: e.parameter.action,
      token: e.parameter.token,
      data: e.parameter.data ? JSON.parse(e.parameter.data) : {},
      meta: e.parameter.meta ? JSON.parse(e.parameter.meta) : {}
    };
  }

  if (!body || typeof body !== 'object') {
    afmFail_('BAD_REQUEST', 'The request could not be read.');
  }

  var data = body.data;
  if (typeof data === 'string') {
    try {
      data = JSON.parse(data);
    } catch (err) {
      data = {};
    }
  }

  return {
    action: afmCleanText_(body.action, 60),
    token: String(body.token == null ? '' : body.token),
    data: data && typeof data === 'object' ? data : {},
    meta: body.meta && typeof body.meta === 'object' ? body.meta : {}
  };
}

/* ========================================================================== */
/*  Responses                                                                 */
/* ========================================================================== */

/**
 * @param {Object} payload
 * @return {GoogleAppsScript.Content.TextOutput}
 */
function afmJsonOutput_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Convert any thrown value into a safe response. Internal details never leave
 * the server.
 * @param {*} err
 * @return {Object}
 */
function afmErrorResponse_(err) {
  if (err && err.isAfmError) {
    return {
      success: false,
      code: err.afmCode || 'REQUEST_FAILED',
      message: err.message || 'The request could not be completed.',
      data: {}
    };
  }

  var reference = afmBytesToHex_(afmRandomBytes_(4)).toUpperCase();
  try {
    console.error('AFM[' + reference + ']', err && err.message ? err.message : String(err));
    if (err && err.stack) console.error(err.stack);
  } catch (loggingError) {
    /* ignore */
  }

  return {
    success: false,
    code: 'SERVER_ERROR',
    message: 'Something went wrong on our side. Please try again in a moment.',
    data: { reference: reference }
  };
}

/**
 * @param {Object} data
 * @return {{message: string, data: Object}}
 */
function afmHandleHealth_() {
  return {
    message: 'Affimarts account API is running.',
    data: {
      status: 'ok',
      version: AFM_VERSION,
      time: new Date().toISOString()
    }
  };
}

/**
 * Remote database bootstrap. Disabled unless AFM_SETUP_KEY exists in Script
 * Properties, so a public deployment cannot be re-initialised by strangers.
 * @param {Object} data
 * @return {{message: string, data: Object}}
 */
function afmHandleInitialize_(data) {
  data = data || {};
  var expected = '';
  try {
    expected = PropertiesService.getScriptProperties().getProperty('AFM_SETUP_KEY') || '';
  } catch (err) {
    expected = '';
  }

  if (!expected) {
    afmFail_(
      'FORBIDDEN',
      'Remote initialisation is disabled. Run initializeDatabase() from the Apps Script editor.'
    );
  }
  if (!afmConstantTimeEquals_(String(data.setupKey || ''), expected)) {
    afmFail_('FORBIDDEN', 'The setup key is not valid.');
  }

  return initializeDatabase();
}

/* ========================================================================== */
/*  HTML pages for email-link fallbacks                                       */
/* ========================================================================== */

/**
 * @param {string} title
 * @param {string} innerHtml
 * @return {GoogleAppsScript.HTML.HtmlOutput}
 */
function afmHtmlPage_(title, innerHtml) {
  var html = '<!doctype html><html><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>' + afmEscapeHtml_(title) + ' · Affimarts</title>' +
    '<style>' +
    'body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F7F3EE;' +
    'font-family:Georgia,"Times New Roman",serif;color:#171717;padding:24px;box-sizing:border-box}' +
    '.card{width:100%;max-width:520px;background:#FFFDF9;border:1px solid #DED6CD;padding:44px 38px;' +
    'box-shadow:0 22px 60px rgba(38,24,20,.10);box-sizing:border-box}' +
    '.brand{font-size:20px;letter-spacing:.2em;font-weight:700;margin-bottom:8px}' +
    '.tag{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;font-size:8.5px;letter-spacing:.18em;' +
    'text-transform:uppercase;color:#6D6865;margin-bottom:30px}' +
    'h1{font-size:28px;font-weight:400;line-height:1.2;margin:0 0 14px}' +
    'p{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;font-size:14px;line-height:1.7;color:#3A3532;margin:0 0 16px}' +
    'a.btn{display:inline-block;margin-top:12px;padding:15px 26px;background:#6D1837;color:#fff;text-decoration:none;' +
    'font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;font-size:10px;font-weight:700;' +
    'letter-spacing:.16em;text-transform:uppercase}' +
    'a.btn:hover{background:#4D0F26}' +
    '.note{font-size:11px;color:#6D6865;margin-top:22px;border-top:1px solid #ECE5DC;padding-top:18px}' +
    '</style></head><body><div class="card">' +
    '<div class="brand">AFFIMARTS</div>' +
    '<div class="tag">Fashion. Inspiration. Smart Shopping.</div>' +
    innerHtml +
    '</div></body></html>';

  return HtmlService.createHtmlOutput(html)
    .setTitle(title + ' · Affimarts')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Confirmation page prevents email link scanners from burning the token.
 * @param {string} token
 * @param {boolean} confirmed
 * @return {GoogleAppsScript.HTML.HtmlOutput}
 */
function afmRenderVerificationPage_(token, confirmed) {
  var safeToken = String(token || '');
  var base = afmApiUrl_();

  if (!confirmed) {
    var confirmUrl = base + '?action=verify&confirm=1&token=' + encodeURIComponent(safeToken);
    return afmHtmlPage_(
      'Confirm your email',
      '<h1>Confirm your email address</h1>' +
      '<p>One quick tap activates your Affimarts account and unlocks saved favourites.</p>' +
      '<a class="btn" href="' + afmEscapeHtml_(confirmUrl) + '">Confirm my email</a>' +
      '<p class="note">If you did not create an Affimarts account, you can close this page.</p>'
    );
  }

  try {
    var result = verifyEmail({ token: safeToken });
    return afmHtmlPage_(
      'Email confirmed',
      '<h1>You are confirmed</h1>' +
      '<p>' + afmEscapeHtml_(result.message) + '</p>' +
      '<a class="btn" href="' + afmEscapeHtml_(afmAccountPageUrl_()) + '">Go to my account</a>' +
      '<p class="note">For your security this link can only be used once.</p>'
    );
  } catch (err) {
    var message = err && err.isAfmError
      ? err.message
      : 'We could not confirm this link. Please request a new verification email.';
    return afmHtmlPage_(
      'Verification problem',
      '<h1>This link did not work</h1>' +
      '<p>' + afmEscapeHtml_(message) + '</p>' +
      '<a class="btn" href="' + afmEscapeHtml_(afmAccountPageUrl_()) + '">Open my account</a>'
    );
  }
}

/**
 * @param {string} token
 * @return {GoogleAppsScript.HTML.HtmlOutput}
 */
function afmRenderResetRedirect_(token) {
  var target = afmAccountPageUrl_();
  var separator = target.indexOf('?') === -1 ? '?' : '&';
  var url = target + separator + 'reset=' + encodeURIComponent(String(token || ''));

  return afmHtmlPage_(
    'Reset your password',
    '<h1>Reset your password</h1>' +
    '<p>Continue to the secure Affimarts account page to choose a new password. This link expires 30 minutes after it was requested.</p>' +
    '<a class="btn" href="' + afmEscapeHtml_(url) + '">Continue</a>' +
    '<p class="note">If you did not request a password reset, you can ignore this page.</p>'
  );
}

/**
 * @return {GoogleAppsScript.HTML.HtmlOutput}
 */
function afmRenderInfoPage_() {
  return afmHtmlPage_(
    'Affimarts Account API',
    '<h1>Affimarts account service</h1>' +
    '<p>This endpoint powers sign-in, registration, favourites and profile settings for ' +
    '<a href="' + afmEscapeHtml_(afmConfig_('SITE_URL')) + '" style="color:#6D1837;">affimarts.com</a>.</p>' +
    '<p class="note">API version ' + afmEscapeHtml_(AFM_VERSION) + '. Requests must be sent as POST.</p>'
  );
}

/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — CONFIGURATION
 * ============================================================================
 * Single source of truth for the backend. Values can be overridden without
 * editing code by adding Script Properties (Project Settings > Script
 * Properties) named AFM_<KEY>, e.g. AFM_SESSION_TTL_MINUTES = 240.
 *
 * Nothing in this file is a secret. Secrets (the setup key) live in Script
 * Properties, never in source code.
 * ============================================================================
 */

var AFM_VERSION = '1.0.0';

var AFM_CONFIG = {
  /* ---- Google Sheet that stores every account record ---- */
  SPREADSHEET_ID: '1wzIcUZPb4gGltN5TxAKYQIGWwObCkRdEuOIKHLWRqT4',

  /* ---- Public URLs ---- */
  SITE_URL: 'https://www.affimarts.com',
  // Where verification / password-reset links send the visitor.
  // Leave blank to fall back to the Apps Script web-app URL.
  ACCOUNT_PAGE_URL: 'https://www.affimarts.com/p/my-account.html',

  /* ---- Email ---- */
  SENDER_NAME: 'Affimarts',
  REPLY_TO: '',            // blank = the Google account that owns the script
  SUPPORT_EMAIL: '',       // shown in email footers, blank = sender address

  /* ---- Session lifetimes ---- */
  SESSION_TTL_MINUTES: 120,        // normal sign-in (idle session length)
  SESSION_REMEMBER_DAYS: 30,       // "Remember me" lifetime
  SESSION_RENEW_RATIO: 0.5,        // renew when less than 50% of lifetime is left

  /* ---- Token lifetimes ---- */
  RESET_TTL_MINUTES: 30,           // password reset link, required by spec
  VERIFY_TTL_HOURS: 48,            // email verification link

  /* ---- Password hashing ---- */
  // PBKDF2-HMAC-SHA256. Apps Script has no native PBKDF2/scrypt/argon2, and
  // every iteration is a remote Utilities call, so a browser-grade work
  // factor (600,000) is not reachable inside the 6-minute execution limit.
  // 1,500 iterations keeps sign-in around 1-3 seconds. Raise this through the
  // AFM_PBKDF2_ITERATIONS script property if your latency budget allows.
  PBKDF2_ITERATIONS: 1500,
  PBKDF2_KEY_BYTES: 32,
  PASSWORD_MIN_LENGTH: 8,
  PASSWORD_MAX_LENGTH: 128,

  /* ---- Abuse protection (CacheService backed) ---- */
  MAX_LOGIN_ATTEMPTS: 5,           // per email + device, per window
  LOGIN_WINDOW_SECONDS: 900,       // 15 minutes
  MAX_RESET_REQUESTS: 3,           // per email, per window
  RESET_WINDOW_SECONDS: 3600,      // 1 hour
  MAX_VERIFY_RESENDS: 3,
  VERIFY_RESEND_WINDOW_SECONDS: 3600,
  MAX_REGISTRATIONS_PER_DEVICE: 5,
  REGISTRATION_WINDOW_SECONDS: 3600,

  /* ---- Data limits ---- */
  MAX_FAVORITES: 200,
  MAX_NAME_LENGTH: 80,
  MAX_TITLE_LENGTH: 180,
  MAX_URL_LENGTH: 800,
  MIN_AGE: 13,

  /* ---- Locking ---- */
  LOCK_TIMEOUT_MS: 30000,

  /* ---- Diagnostics (never enables secret logging) ---- */
  DEBUG: false
};

/**
 * Read a configuration value, allowing a Script Property override.
 * @param {string} key
 * @return {*}
 */
function afmConfig_(key) {
  var fallback = AFM_CONFIG[key];
  var raw = null;
  try {
    raw = PropertiesService.getScriptProperties().getProperty('AFM_' + key);
  } catch (err) {
    raw = null;
  }
  if (raw === null || raw === undefined || raw === '') return fallback;

  if (typeof fallback === 'number') {
    var num = Number(raw);
    return isNaN(num) ? fallback : num;
  }
  if (typeof fallback === 'boolean') return String(raw).toLowerCase() === 'true';
  return raw;
}

/**
 * Open the account spreadsheet.
 * @return {GoogleAppsScript.Spreadsheet.Spreadsheet}
 */
function afmSpreadsheet_() {
  var id = afmConfig_('SPREADSHEET_ID');
  if (!id) afmFail_('CONFIG_ERROR', 'The account spreadsheet is not configured.');
  return SpreadsheetApp.openById(id);
}

/**
 * The deployed web-app URL (…/exec). Available at runtime, not in the editor.
 * @return {string}
 */
function afmApiUrl_() {
  try {
    var url = ScriptApp.getService().getUrl();
    if (url) return url;
  } catch (err) {
    /* getUrl() throws when the script is not deployed as a web app. */
  }
  return afmConfig_('API_URL') || '';
}

/**
 * Base URL for links inside emails.
 * @return {string}
 */
function afmAccountPageUrl_() {
  var configured = afmConfig_('ACCOUNT_PAGE_URL');
  if (configured) return configured;
  return afmConfig_('SITE_URL') || afmApiUrl_();
}

/**
 * Build a verification / reset link.
 * @param {string} kind "verify" or "reset"
 * @param {string} token raw single-use token
 * @return {string}
 */
function afmBuildLink_(kind, token) {
  var base = afmAccountPageUrl_();
  if (!base) base = afmApiUrl_();
  var separator = base.indexOf('?') === -1 ? '?' : '&';
  return base + separator + kind + '=' + encodeURIComponent(token);
}

/**
 * Create a structured, catchable application error.
 * @param {string} code machine readable error code
 * @param {string} message safe user-facing message
 * @return {Error}
 */
function afmError_(code, message) {
  var err = new Error(message || code);
  err.isAfmError = true;
  err.afmCode = code;
  return err;
}

/**
 * Throw a structured application error.
 * @param {string} code
 * @param {string} message
 */
function afmFail_(code, message) {
  throw afmError_(code, message);
}

/**
 * Log only when DEBUG is enabled. Never pass secrets to this function.
 * @param {...*} args
 */
function afmLog_() {
  if (!afmConfig_('DEBUG')) return;
  try {
    console.log.apply(console, Array.prototype.slice.call(arguments));
  } catch (err) {
    /* console is unavailable in some contexts. */
  }
}

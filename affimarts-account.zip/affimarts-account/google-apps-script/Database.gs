/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — DATABASE
 * ============================================================================
 * Google Sheets is the database. This file owns:
 *   • sheet creation / header creation
 *   • row <-> object mapping
 *   • user lookups, inserts and updates
 *   • favourites persistence
 *   • LockService protection for read-modify-write sequences
 *
 * Every write goes through a script lock so two simultaneous requests can
 * never create duplicate users or duplicate favourites.
 * ============================================================================
 */

/**
 * Canonical schema. Column order matters — it is the contract with the spec
 * and with any existing data already in the spreadsheet.
 */
var AFM_SHEET_DEFS = {
  Users: {
    headers: [
      'User ID', 'Full Name', 'Email', 'Password Hash', 'Password Salt',
      'Mobile Number', 'Gender', 'Date of Birth', 'Registration Date',
      'Account Status', 'Email Verified', 'Last Login', 'Updated At'
    ],
    widths: [160, 200, 240, 320, 120, 140, 120, 120, 180, 120, 110, 180, 180]
  },
  Sessions: {
    headers: [
      'Session ID', 'User ID', 'Session Token Hash', 'Created At',
      'Expires At', 'Revoked'
    ],
    widths: [200, 160, 320, 180, 180, 90]
  },
  PasswordReset: {
    headers: [
      'User ID', 'Reset Token Hash', 'Created At', 'Expires At', 'Used'
    ],
    widths: [160, 320, 180, 180, 90]
  },
  EmailVerification: {
    headers: [
      'User ID', 'Verification Token Hash', 'Created At', 'Expires At', 'Used'
    ],
    widths: [160, 320, 180, 180, 90]
  },
  Favorites: {
    headers: [
      'Favorite ID', 'User ID', 'Product Title', 'Product URL',
      'Image URL', 'Added At'
    ],
    widths: [200, 160, 300, 380, 380, 180]
  }
};

/* ========================================================================== */
/*  Sheet access                                                              */
/* ========================================================================== */

/**
 * Get a sheet, creating it with headers if it does not exist.
 * @param {string} name
 * @return {GoogleAppsScript.Spreadsheet.Sheet}
 */
function afmGetSheet_(name) {
  var def = AFM_SHEET_DEFS[name];
  if (!def) afmFail_('DATABASE_ERROR', 'Unknown data table.');

  var ss = afmSpreadsheet_();
  var sheet = ss.getSheetByName(name);

  if (!sheet) {
    sheet = ss.insertSheet(name);
    afmWriteHeaders_(sheet, def);
    return sheet;
  }

  /* A pre-existing but empty sheet still needs its header row. */
  if (sheet.getLastRow() === 0) {
    afmWriteHeaders_(sheet, def);
  }
  return sheet;
}

/**
 * @param {GoogleAppsScript.Spreadsheet.Sheet} sheet
 * @param {{headers: string[], widths: number[]}} def
 */
function afmWriteHeaders_(sheet, def) {
  var range = sheet.getRange(1, 1, 1, def.headers.length);
  range.setValues([def.headers]);
  range.setFontWeight('bold');
  range.setFontFamily('Arial');
  range.setFontSize(10);
  range.setBackground('#6D1837');
  range.setFontColor('#FFFFFF');
  range.setVerticalAlignment('middle');
  sheet.setFrozenRows(1);
  sheet.setRowHeight(1, 32);

  for (var i = 0; i < def.widths.length; i++) {
    sheet.setColumnWidth(i + 1, def.widths[i]);
  }
}

/**
 * Read a table into headers + raw rows.
 * @param {string} name
 * @return {{sheet: GoogleAppsScript.Spreadsheet.Sheet, headers: string[], rows: Array<Array<*>>}}
 */
function afmTable_(name) {
  var sheet = afmGetSheet_(name);
  var def = AFM_SHEET_DEFS[name];
  var lastRow = sheet.getLastRow();
  var lastColumn = sheet.getLastColumn();

  if (lastRow < 1 || lastColumn < 1) {
    return { sheet: sheet, headers: def.headers.slice(0), rows: [] };
  }

  var values = sheet.getRange(1, 1, lastRow, Math.max(lastColumn, def.headers.length)).getValues();
  var headers = (values[0] || []).map(function (header) {
    return afmCleanText_(header, 80);
  });

  /* Repair a truncated / renamed header row so lookups keep working. */
  var repaired = false;
  for (var i = 0; i < def.headers.length; i++) {
    if (!headers[i]) {
      headers[i] = def.headers[i];
      repaired = true;
    }
  }
  if (repaired) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  }

  return { sheet: sheet, headers: headers, rows: values.slice(1) };
}

/**
 * Map a raw row to an object keyed by header.
 * @param {string[]} headers
 * @param {Array<*>} row
 * @return {Object}
 */
function afmRowObject_(headers, row) {
  var obj = {};
  for (var i = 0; i < headers.length; i++) {
    if (!headers[i]) continue;
    obj[headers[i]] = row[i];
  }
  return obj;
}

/**
 * @param {string} name
 * @param {Array<*>} values
 */
function afmAppendRow_(name, values) {
  var sheet = afmGetSheet_(name);
  sheet.appendRow(values);
}

/**
 * Update specific columns of one row.
 * @param {string} name
 * @param {number} rowIndex 1-based sheet row
 * @param {Object} updates header -> value
 */
function afmUpdateRow_(name, rowIndex, updates) {
  var table = afmTable_(name);
  var keys = Object.keys(updates || {});
  for (var i = 0; i < keys.length; i++) {
    var column = table.headers.indexOf(keys[i]) + 1;
    if (column < 1) continue;
    table.sheet.getRange(rowIndex, column).setValue(updates[keys[i]]);
  }
}

/**
 * Run a function while holding the script lock.
 * @param {Function} fn
 * @return {*}
 */
function afmWithLock_(fn) {
  var lock = LockService.getScriptLock();
  var acquired = false;
  try {
    acquired = lock.tryLock(Number(afmConfig_('LOCK_TIMEOUT_MS')) || 30000);
  } catch (err) {
    acquired = false;
  }
  if (!acquired) {
    afmFail_('SERVER_BUSY', 'The account service is busy. Please try again in a moment.');
  }
  try {
    return fn();
  } finally {
    try {
      lock.releaseLock();
    } catch (err) {
      /* already released */
    }
  }
}

/* ========================================================================== */
/*  Value coercion                                                            */
/* ========================================================================== */

/**
 * @param {*} value
 * @return {string} ISO timestamp or ''
 */
function afmToIso_(value) {
  if (!value) return '';
  if (value instanceof Date) return value.toISOString();
  var text = String(value);
  var parsed = new Date(text);
  return isNaN(parsed.getTime()) ? text : parsed.toISOString();
}

/**
 * Calendar dates are not instants. Sheets may return a Date at local midnight,
 * so format the local components instead of slicing a UTC ISO string (which
 * would shift the day in positive timezones such as IST).
 * @param {*} value
 * @return {string} YYYY-MM-DD or ''
 */
function afmDateOnly_(value) {
  if (!value) return '';
  if (value instanceof Date) {
    if (isNaN(value.getTime())) return '';
    var month = ('0' + (value.getMonth() + 1)).slice(-2);
    var day = ('0' + value.getDate()).slice(-2);
    return value.getFullYear() + '-' + month + '-' + day;
  }
  var text = String(value);
  var match = /^(\d{4})-(\d{2})-(\d{2})/.exec(text);
  if (match) return match[1] + '-' + match[2] + '-' + match[3];
  var parsed = new Date(text);
  if (isNaN(parsed.getTime())) return '';
  return afmDateOnly_(parsed);
}

/**
 * @param {*} value
 * @return {boolean}
 */
function afmToBool_(value) {
  if (value === true) return true;
  if (value === false || value === null || value === undefined || value === '') return false;
  var text = String(value).trim().toLowerCase();
  return text === 'true' || text === 'yes' || text === '1' || text === 'verified';
}

/**
 * @param {string} userId
 * @return {string}
 */
function afmInitials_(fullName) {
  var parts = afmCleanText_(fullName, 80).split(' ').filter(function (part) {
    return !!part;
  });
  if (!parts.length) return 'AF';
  var first = parts[0].charAt(0);
  var last = parts.length > 1 ? parts[parts.length - 1].charAt(0) : '';
  return (first + last).toUpperCase();
}

/* ========================================================================== */
/*  Users                                                                     */
/* ========================================================================== */

/**
 * Convert a Users row into a typed object.
 * @param {string[]} headers
 * @param {Array<*>} row
 * @return {Object}
 */
function afmUserFromRow_(headers, row) {
  var raw = afmRowObject_(headers, row);
  return {
    userId: String(raw['User ID'] || ''),
    fullName: String(raw['Full Name'] || ''),
    email: afmNormalizeEmail_(raw['Email'] || ''),
    passwordHash: String(raw['Password Hash'] || ''),
    passwordSalt: String(raw['Password Salt'] || ''),
    mobile: String(raw['Mobile Number'] || ''),
    gender: String(raw['Gender'] || ''),
    dob: afmDateOnly_(raw['Date of Birth']),
    registrationDate: afmToIso_(raw['Registration Date']),
    status: String(raw['Account Status'] || 'active').toLowerCase() || 'active',
    emailVerified: afmToBool_(raw['Email Verified']),
    lastLogin: afmToIso_(raw['Last Login']),
    updatedAt: afmToIso_(raw['Updated At'])
  };
}

/**
 * Public representation — never includes hash, salt or internal row numbers.
 * @param {Object} user
 * @return {Object}
 */
function afmPublicUser_(user) {
  if (!user) return null;
  return {
    userId: user.userId,
    fullName: user.fullName,
    initials: afmInitials_(user.fullName),
    email: user.email,
    mobile: user.mobile || '',
    gender: user.gender || '',
    dateOfBirth: user.dob || '',
    registrationDate: user.registrationDate || '',
    accountStatus: user.status || 'active',
    emailVerified: !!user.emailVerified,
    lastLogin: user.lastLogin || ''
  };
}

/**
 * @param {string} email
 * @return {{user: Object, rowIndex: number}|null}
 */
function afmFindUserByEmail_(email) {
  var target = afmNormalizeEmail_(email);
  if (!target) return null;

  var table = afmTable_('Users');
  for (var i = 0; i < table.rows.length; i++) {
    if (afmNormalizeEmail_(table.rows[i][2]) === target) {
      return { user: afmUserFromRow_(table.headers, table.rows[i]), rowIndex: i + 2 };
    }
  }
  return null;
}

/**
 * @param {string} userId
 * @return {{user: Object, rowIndex: number}|null}
 */
function afmFindUserById_(userId) {
  var target = String(userId || '');
  if (!target) return null;

  var table = afmTable_('Users');
  for (var i = 0; i < table.rows.length; i++) {
    if (String(table.rows[i][0]) === target) {
      return { user: afmUserFromRow_(table.headers, table.rows[i]), rowIndex: i + 2 };
    }
  }
  return null;
}

/**
 * Generate a collision-free public user id.
 * @return {string}
 */
function afmGenerateUserId_() {
  var table = afmTable_('Users');
  var existing = {};
  for (var i = 0; i < table.rows.length; i++) {
    existing[String(table.rows[i][0])] = true;
  }

  var stamp = Utilities.formatDate(new Date(), 'UTC', 'yyyyMMdd');
  for (var attempt = 0; attempt < 12; attempt++) {
    var candidate = 'AFM-' + stamp + '-' + afmBytesToHex_(afmRandomBytes_(4)).toUpperCase();
    if (!existing[candidate]) return candidate;
  }
  afmFail_('SERVER_ERROR', 'Could not allocate a new account id. Please try again.');
  return '';
}

/**
 * Insert a new user row. Caller must hold the script lock.
 * @param {Object} record
 */
function afmInsertUser_(record) {
  var sheet = afmGetSheet_('Users');
  sheet.appendRow([
    record.userId,
    record.fullName,
    record.email,
    record.passwordHash,
    record.passwordSalt,
    record.mobile || '',
    record.gender || '',
    record.dob || '',
    record.registrationDate,
    record.status || 'active',
    !!record.emailVerified,
    record.lastLogin || '',
    record.updatedAt || record.registrationDate
  ]);
}

/**
 * Update a user row.
 * @param {number} rowIndex
 * @param {Object} fields header -> value
 */
function afmUpdateUser_(rowIndex, fields) {
  var updates = {};
  var map = {
    fullName: 'Full Name',
    email: 'Email',
    passwordHash: 'Password Hash',
    passwordSalt: 'Password Salt',
    mobile: 'Mobile Number',
    gender: 'Gender',
    dob: 'Date of Birth',
    status: 'Account Status',
    emailVerified: 'Email Verified',
    lastLogin: 'Last Login'
  };

  Object.keys(fields || {}).forEach(function (key) {
    if (key === 'updatedAt') return;
    if (map[key]) updates[map[key]] = fields[key];
  });
  updates['Updated At'] = new Date().toISOString();

  afmUpdateRow_('Users', rowIndex, updates);
}

/* ========================================================================== */
/*  Favourites                                                                */
/* ========================================================================== */

/**
 * @param {string} userId
 * @return {Array<Object>}
 */
function afmListFavorites_(userId) {
  var table = afmTable_('Favorites');
  var out = [];
  for (var i = 0; i < table.rows.length; i++) {
    var row = table.rows[i];
    if (String(row[1]) !== String(userId)) continue;
    out.push({
      favoriteId: String(row[0] || ''),
      title: String(row[2] || ''),
      url: String(row[3] || ''),
      image: String(row[4] || ''),
      addedAt: afmToIso_(row[5]),
      rowIndex: i + 2
    });
  }

  out.sort(function (a, b) {
    return String(b.addedAt).localeCompare(String(a.addedAt));
  });
  return out;
}

/**
 * @param {string} userId
 * @param {string} url
 * @return {{favorite: Object, rowIndex: number}|null}
 */
function afmFindFavoriteByUrl_(userId, url) {
  var target = String(url || '');
  var list = afmListFavorites_(userId);
  for (var i = 0; i < list.length; i++) {
    if (list[i].url === target) return { favorite: list[i], rowIndex: list[i].rowIndex };
  }
  return null;
}

/* ========================================================================== */
/*  Database bootstrap                                                        */
/* ========================================================================== */

/**
 * Create every sheet, header and formatting rule if missing. Idempotent.
 * Run this once from the Apps Script editor after adding the files.
 * @return {{message: string, data: Object}}
 */
function initializeDatabase() {
  var ss = afmSpreadsheet_();
  var created = [];
  var existing = [];

  Object.keys(AFM_SHEET_DEFS).forEach(function (name) {
    var sheet = ss.getSheetByName(name);
    if (!sheet) {
      sheet = ss.insertSheet(name);
      afmWriteHeaders_(sheet, AFM_SHEET_DEFS[name]);
      created.push(name);
    } else {
      if (sheet.getLastRow() === 0) afmWriteHeaders_(sheet, AFM_SHEET_DEFS[name]);
      existing.push(name);
    }
  });

  /* Remove the default empty "Sheet1" only when it is genuinely unused. */
  var blank = ss.getSheetByName('Sheet1');
  if (blank && blank.getLastRow() === 0 && blank.getLastColumn() === 0 && ss.getSheets().length > 1) {
    try {
      ss.deleteSheet(blank);
    } catch (err) {
      /* ignore */
    }
  }

  return {
    message: 'Database ready.',
    data: {
      spreadsheetId: ss.getId(),
      spreadsheetUrl: ss.getUrl(),
      created: created,
      existing: existing,
      version: AFM_VERSION
    }
  };
}

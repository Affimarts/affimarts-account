/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — EMAIL SERVICE
 * ============================================================================
 * Transactional email for verification and password recovery.
 * Uses MailApp (or GmailApp as a fallback) from the Google account that owns
 * the Apps Script project. Quotas apply: a consumer Gmail account can send
 * 100 recipients/day (Workspace: 1,500).
 * ============================================================================
 */

/**
 * @param {string} to
 * @param {string} subject
 * @param {string} html
 * @param {string} text
 * @return {{sent: boolean, error: string}}
 */
function afmSendMail_(to, subject, html, text) {
  var options = {
    name: afmConfig_('SENDER_NAME') || 'Affimarts',
    htmlBody: html,
    body: text
  };

  var replyTo = afmConfig_('REPLY_TO');
  if (replyTo) options.replyTo = replyTo;

  try {
    MailApp.sendEmail(to, subject, text, options);
    return { sent: true, error: '' };
  } catch (err) {
    afmLog_('MailApp failed, trying GmailApp', err && err.message);
    try {
      GmailApp.sendEmail(to, subject, text, options);
      return { sent: true, error: '' };
    } catch (fallbackErr) {
      afmLog_('Email delivery failed', fallbackErr && fallbackErr.message);
      return { sent: false, error: 'Email delivery failed.' };
    }
  }
}

/**
 * Shared branded email shell.
 * @param {string} title
 * @param {string} bodyHtml
 * @param {string} footerHtml
 * @return {string}
 */
function afmEmailShell_(title, bodyHtml, footerHtml) {
  var site = afmConfig_('SITE_URL') || 'https://www.affimarts.com';
  return '' +
    '<!doctype html><html><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>' + afmEscapeHtml_(title) + '</title></head>' +
    '<body style="margin:0;padding:0;background:#F7F3EE;">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F7F3EE;padding:28px 12px;">' +
    '<tr><td align="center">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#FFFDF9;border:1px solid #DED6CD;">' +
    '<tr><td style="padding:28px 32px 22px;border-bottom:1px solid #ECE5DC;">' +
    '<div style="font-family:Georgia,\'Times New Roman\',serif;font-size:22px;letter-spacing:.18em;color:#171717;font-weight:bold;">AFFIMARTS</div>' +
    '<div style="font-family:Arial,Helvetica,sans-serif;font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:#6D6865;margin-top:7px;">Fashion. Inspiration. Smart Shopping.</div>' +
    '</td></tr>' +
    '<tr><td style="padding:32px;">' +
    '<h1 style="margin:0 0 16px;font-family:Georgia,\'Times New Roman\',serif;font-size:25px;line-height:1.25;font-weight:normal;color:#171717;">' +
    afmEscapeHtml_(title) + '</h1>' +
    bodyHtml +
    '</td></tr>' +
    '<tr><td style="padding:22px 32px 28px;border-top:1px solid #ECE5DC;">' +
    '<p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.7;color:#6D6865;">' +
    footerHtml +
    '</p>' +
    '<p style="margin:12px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.7;color:#6D6865;">' +
    '<a href="' + afmEscapeHtml_(site) + '" style="color:#6D1837;text-decoration:none;">' + afmEscapeHtml_(site.replace(/^https?:\/\//, '')) + '</a>' +
    '</p>' +
    '</td></tr>' +
    '</table>' +
    '<p style="margin:18px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:10px;color:#8A827C;">' +
    'You received this email because an account action was requested for this address.' +
    '</p>' +
    '</td></tr></table></body></html>';
}

/**
 * Minimal HTML escaping for email templates.
 * @param {*} value
 * @return {string}
 */
function afmEscapeHtml_(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Branded CTA button.
 * @param {string} url
 * @param {string} label
 * @return {string}
 */
function afmEmailButton_(url, label) {
  return '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px 0;"><tr>' +
    '<td style="background:#6D1837;">' +
    '<a href="' + afmEscapeHtml_(url) + '" style="display:inline-block;padding:15px 28px;font-family:Arial,Helvetica,sans-serif;' +
    'font-size:11px;font-weight:bold;letter-spacing:.16em;text-transform:uppercase;color:#FFFFFF;text-decoration:none;">' +
    afmEscapeHtml_(label) + '</a></td></tr></table>';
}

/**
 * @param {string} url
 * @return {string}
 */
function afmEmailLinkFallback_(url) {
  return '<p style="margin:18px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.7;color:#6D6865;">' +
    'If the button does not work, copy this link into your browser:<br>' +
    '<span style="word-break:break-all;color:#6D1837;">' + afmEscapeHtml_(url) + '</span></p>';
}

/**
 * Send the account verification email.
 * @param {Object} user
 * @param {string} token raw verification token
 * @return {{sent: boolean, error: string}}
 */
function afmSendVerificationEmail_(user, token) {
  var url = afmBuildLink_('verify', token);
  var hours = Number(afmConfig_('VERIFY_TTL_HOURS')) || 48;
  var name = afmEscapeHtml_(user.fullName || 'there');

  var body =
    '<p style="margin:0 0 16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.75;color:#3A3532;">' +
    'Hi ' + name + ',</p>' +
    '<p style="margin:0 0 16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.75;color:#3A3532;">' +
    'Welcome to Affimarts. Confirm your email address to activate your account, save favourites and keep your style edits in one place.</p>' +
    afmEmailButton_(url, 'Confirm my email') +
    '<p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.75;color:#6D6865;">' +
    'This link expires in ' + hours + ' hours and can only be used once.</p>' +
    afmEmailLinkFallback_(url);

  var text = 'Hi ' + (user.fullName || 'there') + ',\n\n' +
    'Confirm your Affimarts email address:\n' + url + '\n\n' +
    'This link expires in ' + hours + ' hours and can only be used once.\n\n' +
    'If you did not create an account, you can ignore this email.';

  return afmSendMail_(
    user.email,
    'Confirm your Affimarts account',
    afmEmailShell_('Confirm your email address', body,
      'This link expires in ' + hours + ' hours and can only be used once. If you did not create an Affimarts account, you can safely ignore this email.'),
    text
  );
}

/**
 * Send the password reset email.
 * @param {Object} user
 * @param {string} token raw reset token
 * @return {{sent: boolean, error: string}}
 */
function afmSendPasswordResetEmail_(user, token) {
  var url = afmBuildLink_('reset', token);
  var minutes = Number(afmConfig_('RESET_TTL_MINUTES')) || 30;
  var name = afmEscapeHtml_(user.fullName || 'there');

  var body =
    '<p style="margin:0 0 16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.75;color:#3A3532;">' +
    'Hi ' + name + ',</p>' +
    '<p style="margin:0 0 16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.75;color:#3A3532;">' +
    'We received a request to reset the password for your Affimarts account. Choose a new password using the button below.</p>' +
    afmEmailButton_(url, 'Reset my password') +
    '<p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.75;color:#6D6865;">' +
    'This link expires in ' + minutes + ' minutes and can only be used once. If you did not request a reset, no action is needed — your password stays unchanged.</p>' +
    afmEmailLinkFallback_(url);

  var text = 'Hi ' + (user.fullName || 'there') + ',\n\n' +
    'Reset your Affimarts password:\n' + url + '\n\n' +
    'This link expires in ' + minutes + ' minutes and can only be used once.\n\n' +
    'If you did not request a reset, you can ignore this email.';

  return afmSendMail_(
    user.email,
    'Reset your Affimarts password',
    afmEmailShell_('Reset your password', body,
      'This link expires in ' + minutes + ' minutes and can only be used once. If you did not request a reset, your password remains unchanged.'),
    text
  );
}

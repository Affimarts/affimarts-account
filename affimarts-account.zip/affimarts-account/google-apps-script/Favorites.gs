/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — FAVORITES
 * ============================================================================
 * Saved products and articles. Ownership is always taken from the session;
 * the frontend cannot read or delete another user's favourites.
 * ============================================================================
 */

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function getFavorites(data, context) {
  var auth = afmAuthFromContext_(context);
  var list = afmListFavorites_(auth.user.userId).map(function (item) {
    return {
      favoriteId: item.favoriteId,
      title: item.title,
      url: item.url,
      image: item.image,
      addedAt: item.addedAt
    };
  });

  return {
    message: list.length ? 'Favorites loaded.' : 'You have not saved any favourites yet.',
    data: {
      favorites: list,
      count: list.length,
      limit: Number(afmConfig_('MAX_FAVORITES')) || 200
    }
  };
}

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function addFavorite(data, context) {
  data = data || {};
  var auth = afmAuthFromContext_(context);

  var title = afmCleanText_(data.title, afmConfig_('MAX_TITLE_LENGTH') || 180);
  if (!title) afmFail_('INVALID_TITLE', 'A product title is required.');

  var url = afmNormalizeProductUrl_(data.url);
  var image = afmNormalizeImageUrl_(data.image);

  var saved = afmWithLock_(function () {
    var existing = afmFindFavoriteByUrl_(auth.user.userId, url);
    if (existing) {
      return { favorite: existing.favorite, duplicate: true };
    }

    var list = afmListFavorites_(auth.user.userId);
    var limit = Number(afmConfig_('MAX_FAVORITES')) || 200;
    if (list.length >= limit) {
      afmFail_('FAVORITES_LIMIT', 'You have reached the maximum of ' + limit + ' saved favourites.');
    }

    var favoriteId = 'FAV-' + Utilities.formatDate(new Date(), 'UTC', 'yyyyMMdd') + '-' +
      afmBytesToHex_(afmRandomBytes_(5)).toUpperCase();

    afmAppendRow_('Favorites', [
      favoriteId,
      auth.user.userId,
      title,
      url,
      image,
      new Date().toISOString()
    ]);

    return {
      favorite: {
        favoriteId: favoriteId,
        title: title,
        url: url,
        image: image,
        addedAt: new Date().toISOString()
      },
      duplicate: false
    };
  });

  return {
    message: saved.duplicate
      ? 'This item is already in your favourites.'
      : 'Saved to your favourites.',
    data: {
      favorite: saved.favorite,
      duplicate: saved.duplicate
    }
  };
}

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function removeFavorite(data, context) {
  data = data || {};
  var auth = afmAuthFromContext_(context);
  var favoriteId = afmCleanText_(data.favoriteId, 80);

  if (!favoriteId) afmFail_('INVALID_REQUEST', 'A favourite id is required.');

  var removed = afmWithLock_(function () {
    var table = afmTable_('Favorites');
    for (var i = 0; i < table.rows.length; i++) {
      var row = table.rows[i];
      if (String(row[0]) !== favoriteId) continue;
      if (String(row[1]) !== String(auth.user.userId)) {
        afmFail_('FORBIDDEN', 'That favourite does not belong to your account.');
      }
      table.sheet.deleteRow(i + 2);
      return true;
    }
    return false;
  });

  if (!removed) afmFail_('NOT_FOUND', 'That favourite was already removed.');

  return {
    message: 'Removed from your favourites.',
    data: { favoriteId: favoriteId, removed: true }
  };
}

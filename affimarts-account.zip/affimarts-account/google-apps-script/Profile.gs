/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — PROFILE
 * ============================================================================
 * Read and update the signed-in user's profile. The user id always comes from
 * the validated session — never from the request body.
 * ============================================================================
 */

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function getUserProfile(data, context) {
  var auth = afmAuthFromContext_(context);
  var favorites = afmListFavorites_(auth.user.userId);

  return {
    message: 'Profile loaded.',
    data: {
      user: afmPublicUser_(auth.user),
      session: {
        sessionId: auth.session.sessionId,
        createdAt: auth.session.createdAt,
        expiresAt: auth.session.expiresAt
      },
      stats: {
        favorites: favorites.length,
        memberSince: auth.user.registrationDate
      }
    }
  };
}

/**
 * @param {Object} data
 * @param {Object} context
 * @return {{message: string, data: Object}}
 */
function updateUserProfile(data, context) {
  data = data || {};
  var auth = afmAuthFromContext_(context);

  var fullName = afmCleanText_(data.fullName, afmConfig_('MAX_NAME_LENGTH') || 80);
  var mobile = afmCleanText_(data.mobile, 24);
  var gender = afmNormalizeGender_(data.gender);
  var dob = afmCleanText_(data.dob, 10);

  var nameProblem = afmNameProblem_(fullName);
  if (nameProblem) afmFail_('INVALID_NAME', nameProblem);

  var phoneProblem = afmPhoneProblem_(mobile);
  if (phoneProblem) afmFail_('INVALID_PHONE', phoneProblem);

  var dobProblem = afmDobProblem_(dob);
  if (dobProblem) afmFail_('INVALID_DOB', dobProblem);

  afmWithLock_(function () {
    afmUpdateUser_(auth.rowIndex, {
      fullName: fullName,
      mobile: mobile,
      gender: gender,
      dob: dob
    });
  });

  var refreshed = afmFindUserById_(auth.user.userId);

  return {
    message: 'Your profile has been updated.',
    data: {
      user: afmPublicUser_(refreshed ? refreshed.user : auth.user)
    }
  };
}

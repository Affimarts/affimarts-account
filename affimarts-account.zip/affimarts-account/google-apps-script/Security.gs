/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — SECURITY
 * ============================================================================
 * Token generation, PBKDF2 password hashing, constant-time comparison,
 * validation/sanitisation and abuse throttling.
 *
 * Apps Script has no native password hashing API, so PBKDF2-HMAC-SHA256 is
 * implemented on top of Utilities.computeHmacSha256Signature. Only the salt
 * and the derived hash are stored — never the password.
 * ============================================================================
 */

/* ========================================================================== */
/*  Byte / encoding helpers                                                   */
/* ========================================================================== */

/**
 * Normalise a JavaScript number to a signed byte (-128…127), the format
 * Utilities expects for byte arrays.
 * @param {number} n
 * @return {number}
 */
function afmSignedByte_(n) {
  n = n & 255;
  return n > 127 ? n - 256 : n;
}

/**
 * @param {number[]} bytes
 * @return {string} lowercase hex
 */
function afmBytesToHex_(bytes) {
  var out = '';
  for (var i = 0; i < bytes.length; i++) {
    var b = bytes[i] & 255;
    out += (b < 16 ? '0' : '') + b.toString(16);
  }
  return out;
}

/**
 * @param {number[]} bytes
 * @return {string} base64url without padding
 */
function afmBase64Url_(bytes) {
  return Utilities.base64EncodeWebSafe(bytes).replace(/=+$/, '');
}

/**
 * @param {string} value
 * @return {number[]} signed bytes
 */
function afmBase64UrlToBytes_(value) {
  return Utilities.base64DecodeWebSafe(String(value));
}

/**
 * UTF-8 bytes for a string.
 * @param {string} value
 * @return {number[]}
 */
function afmStringBytes_(value) {
  return Utilities.newBlob(String(value)).getBytes();
}

/**
 * @param {string|number[]} value
 * @return {number[]}
 */
function afmSha256_(value) {
  if (typeof value === 'string') {
    return Utilities.computeDigest(
      Utilities.DigestAlgorithm.SHA_256,
      value,
      Utilities.Charset.UTF_8
    );
  }
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, value);
}

/**
 * @param {string} value
 * @return {string} hex
 */
function afmSha256Hex_(value) {
  return afmBytesToHex_(afmSha256_(value));
}

/**
 * HMAC-SHA256.
 * @param {number[]} keyBytes
 * @param {number[]} messageBytes
 * @return {number[]}
 */
function afmHmac_(keyBytes, messageBytes) {
  return Utilities.computeHmacSha256Signature(messageBytes, keyBytes);
}

/**
 * Cryptographically random bytes.
 * Utilities.getUuid() is a random v4 UUID (122 random bits); two of them
 * hashed together provide a 256-bit seed.
 * @param {number} length 1…32
 * @return {number[]}
 */
function afmRandomBytes_(length) {
  var lengthWanted = Math.max(1, Math.min(32, Number(length) || 32));
  var seed = Utilities.getUuid() + Utilities.getUuid() + Utilities.getUuid();
  return afmSha256_(seed).slice(0, lengthWanted);
}

/**
 * URL-safe random token.
 * @param {number=} length bytes, defaults to 32
 * @return {string}
 */
function afmRandomToken_(length) {
  return afmBase64Url_(afmRandomBytes_(length || 32));
}

/**
 * Hash a bearer token before it is written to the spreadsheet.
 * @param {string} token
 * @return {string} hex
 */
function afmHashToken_(token) {
  return afmSha256Hex_(String(token));
}

/**
 * Compare two strings without leaking length/prefix timing.
 * @param {string} a
 * @param {string} b
 * @return {boolean}
 */
function afmConstantTimeEquals_(a, b) {
  a = String(a);
  b = String(b);
  var diff = a.length ^ b.length;
  var max = Math.max(a.length, b.length);
  for (var i = 0; i < max; i++) {
    diff |= (a.charCodeAt(i % (a.length || 1)) || 0) ^
            (b.charCodeAt(i % (b.length || 1)) || 0);
  }
  return diff === 0;
}

/* ========================================================================== */
/*  Password hashing                                                          */
/* ========================================================================== */

/**
 * PBKDF2-HMAC-SHA256 (RFC 8018).
 * @param {string} password
 * @param {number[]} saltBytes
 * @param {number} iterations
 * @param {number} keyLengthBytes
 * @return {number[]}
 */
function afmPbkdf2_(password, saltBytes, iterations, keyLengthBytes) {
  var passwordBytes = afmStringBytes_(password);
  var hLen = 32;
  var blocks = Math.ceil(keyLengthBytes / hLen);
  var derived = [];

  for (var block = 1; block <= blocks; block++) {
    var index = [
      afmSignedByte_((block >>> 24) & 255),
      afmSignedByte_((block >>> 16) & 255),
      afmSignedByte_((block >>> 8) & 255),
      afmSignedByte_(block & 255)
    ];
    var u = afmHmac_(passwordBytes, saltBytes.concat(index));
    var t = u.slice(0);

    for (var i = 1; i < iterations; i++) {
      u = afmHmac_(passwordBytes, u);
      for (var j = 0; j < hLen; j++) {
        t[j] = afmSignedByte_(t[j] ^ u[j]);
      }
    }
    derived = derived.concat(t);
  }
  return derived.slice(0, keyLengthBytes);
}

/**
 * Derive a storable password record.
 * Format: pbkdf2_sha256$<iterations>$<saltB64url>$<hashB64url>
 * @param {string} password
 * @return {{hash: string, salt: string, iterations: number, algorithm: string}}
 */
function afmHashPassword_(password) {
  var iterations = Math.max(1000, Number(afmConfig_('PBKDF2_ITERATIONS')) || 1500);
  var keyBytes = Number(afmConfig_('PBKDF2_KEY_BYTES')) || 32;
  var salt = afmRandomBytes_(16);
  var derived = afmPbkdf2_(password, salt, iterations, keyBytes);
  var saltText = afmBase64Url_(salt);
  var hashText = afmBase64Url_(derived);

  return {
    algorithm: 'pbkdf2_sha256',
    iterations: iterations,
    salt: saltText,
    hash: 'pbkdf2_sha256$' + iterations + '$' + saltText + '$' + hashText
  };
}

/**
 * Verify a password against a stored record.
 * @param {string} password
 * @param {string} storedHash value of the "Password Hash" column
 * @param {string=} storedSalt value of the "Password Salt" column
 * @return {boolean}
 */
function afmVerifyPassword_(password, storedHash, storedSalt) {
  if (!password || !storedHash) return false;

  var parts = String(storedHash).split('$');
  var algorithm, iterations, saltText, hashText;

  if (parts.length === 4 && parts[0] === 'pbkdf2_sha256') {
    algorithm = parts[0];
    iterations = Number(parts[1]);
    saltText = parts[2];
    hashText = parts[3];
  } else {
    /* Defensive fallback for a legacy plain "$salt$hash" value. */
    algorithm = 'pbkdf2_sha256';
    iterations = Number(afmConfig_('PBKDF2_ITERATIONS')) || 1500;
    saltText = String(storedSalt || '');
    hashText = String(storedHash);
  }

  if (algorithm !== 'pbkdf2_sha256') return false;
  if (!isFinite(iterations) || iterations < 1 || iterations > 200000) return false;
  if (!saltText || !hashText) return false;

  try {
    var derived = afmPbkdf2_(
      password,
      afmBase64UrlToBytes_(saltText),
      iterations,
      Math.max(16, Math.min(64, Number(afmConfig_('PBKDF2_KEY_BYTES')) || 32))
    );
    return afmConstantTimeEquals_(afmBase64Url_(derived), hashText);
  } catch (err) {
    return false;
  }
}

/* ========================================================================== */
/*  Validation and sanitisation                                               */
/* ========================================================================== */

/**
 * Strip control characters and trim. Output is stored as plain text and is
 * always escaped at render time.
 * @param {*} value
 * @param {number} maxLength
 * @return {string}
 */
function afmCleanText_(value, maxLength) {
  if (value === null || value === undefined) return '';
  var text = String(value)
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^\s+|\s+$/g, '');
  var limit = Number(maxLength) || 200;
  return text.slice(0, limit);
}

/**
 * @param {*} value
 * @return {string} trimmed, lowercased email
 */
function afmNormalizeEmail_(value) {
  return afmCleanText_(value, 254).toLowerCase();
}

/**
 * @param {string} email
 * @return {boolean}
 */
function afmIsValidEmail_(email) {
  if (!email || email.length > 254) return false;
  if (email.indexOf('..') !== -1) return false;
  return /^[a-z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i.test(email);
}

/**
 * Server-side password policy. The frontend has the same rules for instant
 * feedback; the server is the authority.
 * @param {string} password
 * @param {{email: string=, fullName: string=}=} context
 * @return {string} empty string when valid, otherwise a user-facing message
 */
function afmPasswordProblem_(password, context) {
  context = context || {};
  var value = String(password == null ? '' : password);
  var min = Number(afmConfig_('PASSWORD_MIN_LENGTH')) || 8;
  var max = Number(afmConfig_('PASSWORD_MAX_LENGTH')) || 128;

  if (value.length < min) {
    return 'Use at least ' + min + ' characters for your password.';
  }
  if (value.length > max) {
    return 'Your password must be ' + max + ' characters or fewer.';
  }
  if (!/[A-Za-z]/.test(value) || !/[0-9]/.test(value)) {
    return 'Include at least one letter and one number in your password.';
  }
  if (/^\s|\s$/.test(value)) {
    return 'Your password cannot start or end with a space.';
  }

  var lowered = value.toLowerCase();
  var common = [
    'password', 'password1', 'password123', '12345678', '123456789',
    'qwerty123', 'iloveyou', 'admin123', 'letmein', 'welcome1',
    'affimarts', 'affimarts1', 'abc12345', '11111111'
  ];
  if (common.indexOf(lowered) !== -1) {
    return 'That password is too common. Please choose a stronger one.';
  }

  var email = afmNormalizeEmail_(context.email || '');
  if (email) {
    var local = email.split('@')[0];
    if (local.length >= 3 && lowered.indexOf(local) !== -1) {
      return 'Your password should not contain your email address.';
    }
  }

  var name = afmCleanText_(context.fullName || '', 80).toLowerCase();
  if (name) {
    var parts = name.split(/\s+/);
    for (var i = 0; i < parts.length; i++) {
      if (parts[i].length >= 4 && lowered.indexOf(parts[i]) !== -1) {
        return 'Your password should not contain your name.';
      }
    }
  }

  return '';
}

/**
 * @param {string} name
 * @return {string} empty string when valid
 */
function afmNameProblem_(name) {
  var value = afmCleanText_(name, afmConfig_('MAX_NAME_LENGTH') || 80);
  if (value.length < 2) return 'Please enter your full name.';
  if (value.length > (afmConfig_('MAX_NAME_LENGTH') || 80)) return 'That name is too long.';
  if (!/^[A-Za-z\u00C0-\u024F\u0900-\u097F.' -]+$/.test(value)) {
    return 'Your name can only contain letters, spaces, apostrophes, dots and hyphens.';
  }
  return '';
}

/**
 * @param {string} phone
 * @return {string} empty string when valid or blank
 */
function afmPhoneProblem_(phone) {
  var value = afmCleanText_(phone, 24);
  if (!value) return '';
  var digits = value.replace(/[^0-9]/g, '');
  if (digits.length < 7 || digits.length > 15) return 'Enter a valid mobile number.';
  if (!/^[+(]?[0-9][0-9\s().-]{4,24}$/.test(value)) return 'Enter a valid mobile number.';
  return '';
}

/**
 * @param {string} gender
 * @return {string} normalised value
 */
function afmNormalizeGender_(gender) {
  var value = afmCleanText_(gender, 24);
  if (!value) return '';
  var allowed = ['Female', 'Male', 'Other', 'Prefer not to say'];
  for (var i = 0; i < allowed.length; i++) {
    if (allowed[i].toLowerCase() === value.toLowerCase()) return allowed[i];
  }
  afmFail_('INVALID_GENDER', 'Please choose a valid gender option.');
  return '';
}

/**
 * @param {string} dob ISO date (YYYY-MM-DD)
 * @return {string} empty string when valid or blank
 */
function afmDobProblem_(dob) {
  var value = afmCleanText_(dob, 10);
  if (!value) return '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return 'Enter your date of birth as YYYY-MM-DD.';

  var parts = value.split('-');
  var date = new Date(Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])));
  if (isNaN(date.getTime()) ||
      date.getUTCFullYear() !== Number(parts[0]) ||
      date.getUTCMonth() !== Number(parts[1]) - 1 ||
      date.getUTCDate() !== Number(parts[2])) {
    return 'Enter a real calendar date.';
  }

  var now = new Date();
  if (date.getTime() > now.getTime()) return 'Your date of birth cannot be in the future.';

  var age = (now.getTime() - date.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
  if (age < (afmConfig_('MIN_AGE') || 13)) {
    return 'You must be at least ' + (afmConfig_('MIN_AGE') || 13) + ' years old to create an account.';
  }
  if (age > 120) return 'Please check your date of birth.';
  return '';
}

/**
 * Product URLs must point at Affimarts or a known shopping destination.
 * @param {string} value
 * @return {string} normalised URL
 */
function afmNormalizeProductUrl_(value) {
  var url = afmCleanText_(value, afmConfig_('MAX_URL_LENGTH') || 800);
  if (!url) afmFail_('INVALID_URL', 'A product link is required.');
  if (!/^https?:\/\//i.test(url)) afmFail_('INVALID_URL', 'Product links must start with https://');

  var host = '';
  var match = /^https?:\/\/([^\/?#]+)/i.exec(url);
  if (match) {
    host = match[1].toLowerCase();
    host = host.replace(/^[^@]*@/, '').replace(/:\d+$/, '');
  }
  if (!host) afmFail_('INVALID_URL', 'That product link is not a valid web address.');

  var allowed = [
    'affimarts.com', 'www.affimarts.com',
    'amazon.in', 'www.amazon.in', 'amazon.com', 'www.amazon.com',
    'amzn.to', 'amzn.in', 'link.amazon',
    'flipkart.com', 'www.flipkart.com', 'fkrt.co',
    'myntra.com', 'www.myntra.com',
    'ajio.com', 'www.ajio.com',
    'meesho.com', 'www.meesho.com'
  ];
  if (allowed.indexOf(host) === -1) {
    afmFail_('INVALID_URL', 'Save links from Affimarts or a supported shopping site.');
  }
  return url;
}

/**
 * Image URLs are only ever rendered inside an <img src>. They still must be
 * http(s) so a javascript: payload can never reach the DOM.
 * @param {string} value
 * @return {string}
 */
function afmNormalizeImageUrl_(value) {
  var url = afmCleanText_(value, afmConfig_('MAX_URL_LENGTH') || 800);
  if (!url) return '';
  if (!/^https:\/\//i.test(url)) afmFail_('INVALID_IMAGE', 'Image links must start with https://');
  return url;
}

/**
 * A device identifier supplied by the browser is untrusted; it is only used
 * as a throttling bucket, never for authorisation.
 * @param {*} value
 * @return {string}
 */
function afmSafeDeviceId_(value) {
  var id = String(value == null ? '' : value).replace(/[^A-Za-z0-9_-]/g, '');
  return id.slice(0, 64) || 'unknown-device';
}

/**
 * @param {string} token
 * @return {string}
 */
function afmRequireToken_(token) {
  var value = String(token == null ? '' : token);
  if (value.length < 16 || value.length > 128 || !/^[A-Za-z0-9_-]+$/.test(value)) {
    afmFail_('SESSION_REQUIRED', 'Please sign in to continue.');
  }
  return value;
}

/* ========================================================================== */
/*  Abuse throttling                                                          */
/* ========================================================================== */

/**
 * @param {string} scope
 * @param {string} identifier
 * @return {string}
 */
function afmRateKey_(scope, identifier) {
  return ('rl_' + scope + '_' + afmSha256Hex_(String(identifier))).slice(0, 240);
}

/**
 * Record one attempt and fail when the limit is exceeded.
 * @param {string} scope
 * @param {string} identifier
 * @param {number} limit
 * @param {number} windowSeconds
 * @param {string} message
 */
function afmRateLimit_(scope, identifier, limit, windowSeconds, message) {
  var cache = CacheService.getScriptCache();
  var key = afmRateKey_(scope, identifier);
  var now = Date.now();
  var state = { count: 0, start: now };

  try {
    var raw = cache.get(key);
    if (raw) {
      var parsed = JSON.parse(raw);
      if (parsed && parsed.start && (now - parsed.start) < windowSeconds * 1000) {
        state = { count: Number(parsed.count) || 0, start: Number(parsed.start) };
      }
    }
  } catch (err) {
    state = { count: 0, start: now };
  }

  state.count += 1;

  try {
    cache.put(key, JSON.stringify(state), Math.max(1, windowSeconds));
  } catch (err) {
    /* A cache failure must not take the whole endpoint down. */
  }

  if (state.count > limit) {
    afmFail_('TOO_MANY_REQUESTS', message || 'Too many attempts. Please wait a few minutes and try again.');
  }
}

/**
 * Clear a throttling bucket (used after a successful login).
 * @param {string} scope
 * @param {string} identifier
 */
function afmRateClear_(scope, identifier) {
  try {
    CacheService.getScriptCache().remove(afmRateKey_(scope, identifier));
  } catch (err) {
    /* ignore */
  }
}

/**
 * Read a throttling bucket without incrementing it.
 * @param {string} scope
 * @param {string} identifier
 * @return {{count: number, start: number}}
 */
function afmRatePeek_(scope, identifier) {
  try {
    var raw = CacheService.getScriptCache().get(afmRateKey_(scope, identifier));
    if (!raw) return { count: 0, start: 0 };
    var parsed = JSON.parse(raw);
    return { count: Number(parsed.count) || 0, start: Number(parsed.start) || 0 };
  } catch (err) {
    return { count: 0, start: 0 };
  }
}

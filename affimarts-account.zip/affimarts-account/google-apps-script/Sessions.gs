/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — SESSIONS
 * ============================================================================
 * Custom bearer-token sessions. The raw token is returned to the browser once
 * and is never written to the spreadsheet — only its SHA-256 hash is stored.
 * Every protected request re-validates the token server-side.
 *
 * "Remember me" simply creates a longer-lived server session (30 days by
 * default). It is not a client-side flag the server trusts.
 * ============================================================================
 */

/**
 * @param {string} userId
 * @param {boolean} remember
 * @return {{token: string, sessionId: string, expiresAt: string, remember: boolean}}
 */
function afmCreateSession_(userId, remember) {
  var token = afmRandomToken_(32);
  var tokenHash = afmHashToken_(token);
  var sessionId = 'SES-' + Utilities.formatDate(new Date(), 'UTC', 'yyyyMMdd') + '-' +
    afmBytesToHex_(afmRandomBytes_(5)).toUpperCase();

  var now = new Date();
  var ttlMs = remember
    ? (Number(afmConfig_('SESSION_REMEMBER_DAYS')) || 30) * 24 * 60 * 60 * 1000
    : (Number(afmConfig_('SESSION_TTL_MINUTES')) || 120) * 60 * 1000;
  var expires = new Date(now.getTime() + ttlMs);

  afmWithLock_(function () {
    /* Opportunistic cleanup keeps the sheet small without a timed trigger. */
    if (Math.random() < 0.15) afmPruneSessions_();
    afmAppendRow_('Sessions', [
      sessionId,
      userId,
      tokenHash,
      now.toISOString(),
      expires.toISOString(),
      false
    ]);
  });

  return {
    token: token,
    sessionId: sessionId,
    expiresAt: expires.toISOString(),
    remember: !!remember
  };
}

/**
 * Resolve a bearer token into a live session + user.
 * Throws SESSION_REQUIRED / SESSION_INVALID when the token is missing,
 * expired, revoked, unknown or belongs to a disabled account.
 *
 * @param {string} token
 * @return {{session: Object, user: Object, rowIndex: number}}
 */
function afmRequireSession_(token) {
  var raw = afmRequireToken_(token);
  var hash = afmHashToken_(raw);

  var table = afmTable_('Sessions');
  var match = null;

  for (var i = 0; i < table.rows.length; i++) {
    if (String(table.rows[i][2]) === hash) {
      match = {
        rowIndex: i + 2,
        sessionId: String(table.rows[i][0] || ''),
        userId: String(table.rows[i][1] || ''),
        createdAt: afmToIso_(table.rows[i][3]),
        expiresAt: afmToIso_(table.rows[i][4]),
        revoked: afmToBool_(table.rows[i][5])
      };
      break;
    }
  }

  if (!match) afmFail_('SESSION_INVALID', 'Your session has ended. Please sign in again.');
  if (match.revoked) afmFail_('SESSION_INVALID', 'This session was signed out. Please sign in again.');

  var expires = new Date(match.expiresAt).getTime();
  if (!isFinite(expires) || expires <= Date.now()) {
    afmRevokeSessionRow_(match.rowIndex);
    afmFail_('SESSION_EXPIRED', 'Your session has expired. Please sign in again.');
  }

  var found = afmFindUserById_(match.userId);
  if (!found) {
    afmRevokeSessionRow_(match.rowIndex);
    afmFail_('SESSION_INVALID', 'Your session is no longer valid. Please sign in again.');
  }

  if (found.user.status !== 'active') {
    afmRevokeAllSessions_(found.user.userId, null);
    afmFail_('ACCOUNT_DISABLED', 'This account is currently disabled. Please contact support.');
  }

  /* Sliding expiration: extend when the session is past half its lifetime. */
  var created = new Date(match.createdAt).getTime();
  var lifetime = expires - created;
  var remaining = expires - Date.now();
  var ratio = Number(afmConfig_('SESSION_RENEW_RATIO')) || 0.5;

  if (lifetime > 0 && remaining < lifetime * ratio) {
    var extended = new Date(Date.now() + lifetime);
    try {
      afmUpdateRow_('Sessions', match.rowIndex, { 'Expires At': extended.toISOString() });
      match.expiresAt = extended.toISOString();
    } catch (err) {
      /* A renewal failure must not reject an otherwise valid session. */
    }
  }

  return { session: match, user: found.user, rowIndex: found.rowIndex };
}

/**
 * @param {number} rowIndex
 */
function afmRevokeSessionRow_(rowIndex) {
  try {
    afmUpdateRow_('Sessions', rowIndex, { Revoked: true });
  } catch (err) {
    /* ignore */
  }
}

/**
 * @param {string} token
 * @return {boolean} true when a session was revoked
 */
function afmRevokeSessionByToken_(token) {
  if (!token) return false;
  var hash = afmHashToken_(token);
  var table = afmTable_('Sessions');
  var revoked = false;

  for (var i = 0; i < table.rows.length; i++) {
    if (String(table.rows[i][2]) === hash) {
      afmRevokeSessionRow_(i + 2);
      revoked = true;
    }
  }
  return revoked;
}

/**
 * Revoke every session for a user.
 * @param {string} userId
 * @param {string=} exceptTokenHash keep this session alive (optional)
 * @return {number} number of sessions revoked
 */
function afmRevokeAllSessions_(userId, exceptTokenHash) {
  var table = afmTable_('Sessions');
  var revoked = 0;

  for (var i = 0; i < table.rows.length; i++) {
    if (String(table.rows[i][1]) !== String(userId)) continue;
    if (afmToBool_(table.rows[i][5])) continue;
    if (exceptTokenHash && String(table.rows[i][2]) === exceptTokenHash) continue;
    afmRevokeSessionRow_(i + 2);
    revoked++;
  }
  return revoked;
}

/**
 * Delete expired / revoked sessions older than 7 days.
 */
function afmPruneSessions_() {
  try {
    var table = afmTable_('Sessions');
    var cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
    var rowsToDelete = [];

    for (var i = 0; i < table.rows.length; i++) {
      var expires = new Date(afmToIso_(table.rows[i][4])).getTime();
      var revoked = afmToBool_(table.rows[i][5]);
      if (isFinite(expires) && expires < cutoff && revoked) {
        rowsToDelete.push(i + 2);
      } else if (isFinite(expires) && expires < cutoff) {
        rowsToDelete.push(i + 2);
      }
    }

    for (var j = rowsToDelete.length - 1; j >= 0; j--) {
      table.sheet.deleteRow(rowsToDelete[j]);
    }
  } catch (err) {
    afmLog_('Session prune skipped', err && err.message);
  }
}

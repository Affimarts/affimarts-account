/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — BACKEND TEST HARNESS (Node.js)
 * ============================================================================
 * Emulates the Google Apps Script services used by the backend (Sheets,
 * Utilities, CacheService, LockService, MailApp, ContentService, HtmlService)
 * so the real .gs files can be executed and asserted without deploying.
 *
 * Run:  node tests/backend.test.js
 * Requires Node 18+ (uses node:crypto and base64url).
 * ============================================================================
 */
'use strict';

const assert = require('node:assert');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

/* -------------------------------------------------------------------------- */
/*  Byte helpers                                                              */
/* -------------------------------------------------------------------------- */

function toBuffer(value) {
  if (typeof value === 'string') return Buffer.from(value, 'utf8');
  if (Buffer.isBuffer(value)) return value;
  if (Array.isArray(value)) return Buffer.from(value.map((b) => b & 255));
  if (value instanceof Uint8Array) return Buffer.from(value);
  return Buffer.from(String(value), 'utf8');
}

function toSigned(buffer) {
  return Array.from(buffer, (b) => (b > 127 ? b - 256 : b));
}

/* -------------------------------------------------------------------------- */
/*  Fake Google Sheets                                                        */
/* -------------------------------------------------------------------------- */

class FakeRange {
  constructor(sheet, row, col, numRows, numCols) {
    this.sheet = sheet;
    this.row = row;
    this.col = col;
    this.numRows = numRows;
    this.numCols = numCols;
  }

  getValues() {
    const out = [];
    for (let r = 0; r < this.numRows; r++) {
      const row = this.sheet.data[this.row - 1 + r] || [];
      const values = [];
      for (let c = 0; c < this.numCols; c++) {
        const value = row[this.col - 1 + c];
        values.push(value === undefined ? '' : value);
      }
      out.push(values);
    }
    return out;
  }

  setValues(matrix) {
    matrix.forEach((values, r) => {
      const rowIndex = this.row - 1 + r;
      this.sheet.ensureRow(rowIndex);
      values.forEach((value, c) => {
        this.sheet.data[rowIndex][this.col - 1 + c] = value;
      });
    });
    return this;
  }

  setValue(value) {
    this.sheet.ensureRow(this.row - 1);
    this.sheet.data[this.row - 1][this.col - 1] = value;
    return this;
  }

  setFontWeight() { return this; }
  setFontFamily() { return this; }
  setFontSize() { return this; }
  setBackground() { return this; }
  setFontColor() { return this; }
  setVerticalAlignment() { return this; }
  setNumberFormat() { return this; }
}

class FakeSheet {
  constructor(name) {
    this.name = name;
    this.data = [];
  }

  ensureRow(index) {
    while (this.data.length <= index) this.data.push([]);
    if (!Array.isArray(this.data[index])) this.data[index] = [];
  }

  getName() { return this.name; }
  getLastRow() { return this.data.length; }
  getLastColumn() {
    return this.data.reduce((max, row) => Math.max(max, row ? row.length : 0), 0);
  }

  getDataRange() {
    return new FakeRange(this, 1, 1, Math.max(1, this.getLastRow()), Math.max(1, this.getLastColumn()));
  }

  getRange(row, col, numRows, numCols) {
    return new FakeRange(this, row, col, numRows || 1, numCols || 1);
  }

  appendRow(values) {
    this.data.push(values.slice());
  }

  deleteRow(rowIndex) {
    this.data.splice(rowIndex - 1, 1);
  }

  setFrozenRows() {}
  setColumnWidth() {}
  setRowHeight() {}
  clear() { this.data = []; }
}

class FakeSpreadsheet {
  constructor(id) {
    this.id = id;
    this.sheets = [];
  }

  getId() { return this.id; }
  getUrl() { return 'https://docs.google.com/spreadsheets/d/' + this.id + '/edit'; }

  getSheetByName(name) {
    return this.sheets.find((sheet) => sheet.name === name) || null;
  }

  insertSheet(name) {
    const sheet = new FakeSheet(name);
    this.sheets.push(sheet);
    return sheet;
  }

  getSheets() { return this.sheets.slice(); }

  deleteSheet(sheet) {
    this.sheets = this.sheets.filter((item) => item !== sheet);
  }
}

/* -------------------------------------------------------------------------- */
/*  Fake Apps Script environment                                              */
/* -------------------------------------------------------------------------- */

const store = {
  spreadsheets: new Map(),
  properties: new Map(),
  cache: new Map(),
  emails: [],
  logs: []
};

function resetStore() {
  store.spreadsheets.clear();
  store.properties.clear();
  store.cache.clear();
  store.emails.length = 0;
  store.logs.length = 0;
}

const SpreadsheetApp = {
  openById(id) {
    if (!store.spreadsheets.has(id)) store.spreadsheets.set(id, new FakeSpreadsheet(id));
    return store.spreadsheets.get(id);
  }
};

const Utilities = {
  DigestAlgorithm: { SHA_256: 'SHA_256' },
  Charset: { UTF_8: 'UTF_8' },

  computeDigest(algorithm, value) {
    if (algorithm !== 'SHA_256') throw new Error('unsupported digest');
    return toSigned(crypto.createHash('sha256').update(toBuffer(value)).digest());
  },

  computeHmacSha256Signature(value, key) {
    return toSigned(crypto.createHmac('sha256', toBuffer(key)).update(toBuffer(value)).digest());
  },

  base64EncodeWebSafe(value) {
    return toBuffer(value).toString('base64url');
  },

  base64DecodeWebSafe(value) {
    return toSigned(Buffer.from(String(value), 'base64url'));
  },

  newBlob(value) {
    const buffer = Buffer.from(String(value), 'utf8');
    return {
      getBytes() { return toSigned(buffer); },
      getDataAsString() { return buffer.toString('utf8'); }
    };
  },

  getUuid() {
    return crypto.randomUUID();
  },

  formatDate(date, timezone, format) {
    const d = date instanceof Date ? date : new Date(date);
    const iso = d.toISOString();
    if (format === 'yyyyMMdd') return iso.slice(0, 10).replace(/-/g, '');
    return iso;
  }
};

const PropertiesService = {
  getScriptProperties() {
    return {
      getProperty(key) {
        return store.properties.has(key) ? store.properties.get(key) : null;
      },
      setProperty(key, value) { store.properties.set(key, String(value)); },
      deleteProperty(key) { store.properties.delete(key); },
      getProperties() {
        return Object.fromEntries(store.properties.entries());
      }
    };
  }
};

const CacheService = {
  getScriptCache() {
    return {
      get(key) {
        const entry = store.cache.get(key);
        if (!entry) return null;
        if (entry.expires && entry.expires < Date.now()) {
          store.cache.delete(key);
          return null;
        }
        return entry.value;
      },
      put(key, value, seconds) {
        store.cache.set(key, {
          value: String(value),
          expires: Date.now() + (Number(seconds) || 600) * 1000
        });
      },
      remove(key) { store.cache.delete(key); }
    };
  }
};

const LockService = {
  getScriptLock() {
    return {
      tryLock() { return true; },
      waitLock() {},
      releaseLock() {}
    };
  }
};

const MailApp = {
  sendEmail(to, subject, body, options) {
    store.emails.push({
      to,
      subject,
      body,
      htmlBody: (options && options.htmlBody) || '',
      name: (options && options.name) || ''
    });
  }
};

const GmailApp = {
  sendEmail(to, subject, body, options) {
    MailApp.sendEmail(to, subject, body, options);
  }
};

const ContentService = {
  MimeType: { JSON: 'application/json', TEXT: 'text/plain' },
  createTextOutput(text) {
    return {
      text: String(text),
      mimeType: 'text/plain',
      setMimeType(type) { this.mimeType = type; return this; },
      getContent() { return this.text; }
    };
  }
};

const HtmlService = {
  XFrameOptionsMode: { ALLOWALL: 'ALLOWALL' },
  createHtmlOutput(html) {
    return {
      html: String(html),
      setTitle() { return this; },
      setXFrameOptionsMode() { return this; },
      getContent() { return this.html; }
    };
  }
};

const ScriptApp = {
  getService() {
    return { getUrl: () => 'https://script.google.com/macros/s/TEST_DEPLOYMENT/exec' };
  }
};

/* -------------------------------------------------------------------------- */
/*  Load the real backend files                                               */
/* -------------------------------------------------------------------------- */

function createBackend() {
  resetStore();

  const sandbox = {
    console: {
      log: (...args) => store.logs.push(args.join(' ')),
      warn: (...args) => store.logs.push(args.join(' ')),
      error: (...args) => store.logs.push(args.join(' '))
    },
    SpreadsheetApp,
    Utilities,
    PropertiesService,
    CacheService,
    LockService,
    MailApp,
    GmailApp,
    ContentService,
    HtmlService,
    ScriptApp,
    Date,
    Math,
    JSON,
    Number,
    String,
    Boolean,
    Array,
    Object,
    RegExp,
    Error,
    isNaN,
    isFinite,
    parseInt,
    parseFloat,
    encodeURIComponent,
    decodeURIComponent,
    setTimeout
  };

  const context = vm.createContext(sandbox);
  const dir = path.join(__dirname, '..', 'google-apps-script');
  const files = [
    'Configuration.gs',
    'Security.gs',
    'Database.gs',
    'Sessions.gs',
    'EmailService.gs',
    'Authentication.gs',
    'Profile.gs',
    'Favorites.gs',
    'Code.gs'
  ];

  for (const file of files) {
    const source = fs.readFileSync(path.join(dir, file), 'utf8');
    vm.runInContext(source, context, { filename: file });
  }

  return context;
}

/* -------------------------------------------------------------------------- */
/*  Test helpers                                                              */
/* -------------------------------------------------------------------------- */

let backend;
let failures = 0;
let passes = 0;
let currentSuite = '';

function suite(name) {
  currentSuite = name;
  console.log('\n' + name);
}

function check(name, fn) {
  try {
    fn();
    passes++;
    console.log('  PASS  ' + name);
  } catch (err) {
    failures++;
    console.log('  FAIL  ' + name);
    console.log('        ' + (err && err.message ? err.message : err));
    if (err && err.stack) {
      console.log(err.stack.split('\n').slice(1, 4).join('\n'));
    }
  }
}

function api(action, data, token) {
  const response = backend.doPost({
    postData: {
      contents: JSON.stringify({
        action,
        token: token || '',
        data: data || {},
        meta: { deviceId: 'test-device-' + Math.random().toString(16).slice(2) }
      })
    }
  });
  return JSON.parse(response.getContent());
}

function emailToken(kind, email) {
  const mail = store.emails.slice().reverse().find((item) => !email || item.to === email);
  if (!mail) throw new Error('No email was sent');
  const pattern = new RegExp(kind + '=([A-Za-z0-9_-]+)');
  const match = pattern.exec(mail.htmlBody) || pattern.exec(mail.body);
  if (!match) throw new Error('No ' + kind + ' token in email');
  return match[1];
}

function userRow(email) {
  const sheet = store.spreadsheets.values().next().value.getSheetByName('Users');
  return sheet.data.find((row) => String(row[2]).toLowerCase() === String(email).toLowerCase());
}

function resetBackend() {
  backend = createBackend();
}

/* -------------------------------------------------------------------------- */
/*  Tests                                                                     */
/* -------------------------------------------------------------------------- */

resetBackend();

suite('Configuration & database bootstrap');
check('spreadsheet id is the supplied Affimarts sheet', () => {
  assert.strictEqual(backend.AFM_CONFIG.SPREADSHEET_ID, '1wzIcUZPb4gGltN5TxAKYQIGWwObCkRdEuOIKHLWRqT4');
});
check('initializeDatabase creates all five sheets with exact headers', () => {
  const result = backend.initializeDatabase();
  const sheet = store.spreadsheets.get(backend.AFM_CONFIG.SPREADSHEET_ID);
  const expected = {
    Users: ['User ID', 'Full Name', 'Email', 'Password Hash', 'Password Salt', 'Mobile Number', 'Gender', 'Date of Birth', 'Registration Date', 'Account Status', 'Email Verified', 'Last Login', 'Updated At'],
    Sessions: ['Session ID', 'User ID', 'Session Token Hash', 'Created At', 'Expires At', 'Revoked'],
    PasswordReset: ['User ID', 'Reset Token Hash', 'Created At', 'Expires At', 'Used'],
    EmailVerification: ['User ID', 'Verification Token Hash', 'Created At', 'Expires At', 'Used'],
    Favorites: ['Favorite ID', 'User ID', 'Product Title', 'Product URL', 'Image URL', 'Added At']
  };
  Object.keys(expected).forEach((name) => {
    const target = sheet.getSheetByName(name);
    assert.ok(target, name + ' sheet missing');
    assert.deepStrictEqual(target.data[0], expected[name]);
  });
  assert.strictEqual(result.data.created.length, 5);
});
check('initializeDatabase via API is locked without a setup key', () => {
  const result = api('initializeDatabase', {});
  assert.strictEqual(result.success, false);
  assert.strictEqual(result.code, 'FORBIDDEN');
});

suite('Password hashing');
check('PBKDF2-HMAC-SHA256 matches the Node reference implementation', () => {
  const salt = Buffer.from('0123456789abcdef', 'utf8');
  const derived = backend.afmPbkdf2_('Str0ngPass!23', toSigned(salt), 1500, 32);
  const reference = crypto.pbkdf2Sync('Str0ngPass!23', salt, 1500, 32, 'sha256');
  assert.strictEqual(Buffer.from(derived.map((b) => b & 255)).toString('hex'), reference.toString('hex'));
});
check('hash format is versioned, salted and verifiable', () => {
  const record = backend.afmHashPassword_('Str0ngPass!23');
  assert.match(record.hash, /^pbkdf2_sha256\$1500\$[A-Za-z0-9_-]+\$[A-Za-z0-9_-]+$/);
  assert.ok(record.salt.length >= 20);
  assert.strictEqual(backend.afmVerifyPassword_('Str0ngPass!23', record.hash, record.salt), true);
  assert.strictEqual(backend.afmVerifyPassword_('wrong-password', record.hash, record.salt), false);
});
check('date-only values keep the calendar day in positive timezones', () => {
  assert.strictEqual(backend.afmDateOnly_('1994-06-15'), '1994-06-15');
  assert.strictEqual(backend.afmDateOnly_(new Date(1994, 5, 15)), '1994-06-15');
  assert.strictEqual(backend.afmDateOnly_(''), '');
});
check('validation rejects weak and common passwords', () => {
  assert.ok(backend.afmPasswordProblem_('short1').length > 0);
  assert.ok(backend.afmPasswordProblem_('password123').length > 0);
  assert.ok(backend.afmPasswordProblem_('alllettersonly').length > 0);
  assert.ok(backend.afmPasswordProblem_('mehta1234', { fullName: 'Aarav Mehta' }).length > 0);
  assert.strictEqual(backend.afmPasswordProblem_('Str0ngPass!23'), '');
  assert.strictEqual(backend.afmPhoneProblem_('(020) 7946 0958'), '');
  assert.ok(backend.afmPhoneProblem_('123').length > 0);
});

suite('Registration');
const primary = {
  fullName: 'Aarav Mehta',
  email: '  Aarav.Mehta@Example.com ',
  password: 'Str0ngPass!23',
  confirmPassword: 'Str0ngPass!23',
  mobile: '+91 98765 43210',
  gender: 'male',
  dob: '1994-06-15'
};

check('creates a user, normalises email and never stores the password', () => {
  const result = api('registerUser', primary);
  assert.strictEqual(result.success, true, JSON.stringify(result));
  assert.strictEqual(result.data.email, 'aarav.mehta@example.com');
  assert.strictEqual(result.data.emailVerified, false);
  assert.strictEqual(result.data.verificationEmailSent, true);

  const row = userRow('aarav.mehta@example.com');
  assert.ok(row, 'user row missing');
  assert.match(String(row[0]), /^AFM-\d{8}-[0-9A-F]{8}$/);
  assert.strictEqual(row[1], 'Aarav Mehta');
  assert.strictEqual(row[5], '+91 98765 43210');
  assert.strictEqual(row[6], 'Male');
  assert.strictEqual(row[7], '1994-06-15');
  assert.strictEqual(row[9], 'active');
  assert.strictEqual(row[10], false);
  assert.ok(!JSON.stringify(row).includes('Str0ngPass!23'), 'plain-text password found in sheet');
  assert.ok(String(row[3]).startsWith('pbkdf2_sha256$'));
});
check('prevents duplicate emails regardless of case', () => {
  const result = api('registerUser', Object.assign({}, primary, {
    email: 'AARAV.MEHTA@example.com',
    mobile: '+91 90000 00000'
  }));
  assert.strictEqual(result.success, false);
  assert.strictEqual(result.code, 'EMAIL_EXISTS');
});
check('rejects invalid input', () => {
  assert.strictEqual(api('registerUser', Object.assign({}, primary, { email: 'not-an-email' })).code, 'INVALID_EMAIL');
  assert.strictEqual(api('registerUser', Object.assign({}, primary, { email: 'new1@example.com', fullName: 'A' })).code, 'INVALID_NAME');
  assert.strictEqual(api('registerUser', Object.assign({}, primary, { email: 'new2@example.com', password: 'short', confirmPassword: 'short' })).code, 'WEAK_PASSWORD');
  assert.strictEqual(api('registerUser', Object.assign({}, primary, { email: 'new3@example.com', confirmPassword: 'different1A' })).code, 'PASSWORD_MISMATCH');
  assert.strictEqual(api('registerUser', Object.assign({}, primary, { email: 'new4@example.com', mobile: '123' })).code, 'INVALID_PHONE');
  assert.strictEqual(api('registerUser', Object.assign({}, primary, { email: 'new5@example.com', dob: '2024-01-01' })).code, 'INVALID_DOB');
  assert.strictEqual(api('registerUser', Object.assign({}, primary, { email: 'new6@example.com', fullName: '<script>alert(1)</script>' })).code, 'INVALID_NAME');
});

suite('Email verification');
check('unverified accounts cannot sign in', () => {
  const result = api('loginUser', { email: primary.email, password: primary.password });
  assert.strictEqual(result.success, false);
  assert.strictEqual(result.code, 'EMAIL_NOT_VERIFIED');
});
check('verification token is single use and marks the account verified', () => {
  const token = emailToken('verify', 'aarav.mehta@example.com');
  const first = api('verifyEmail', { token });
  assert.strictEqual(first.success, true, JSON.stringify(first));
  assert.strictEqual(userRow('aarav.mehta@example.com')[10], true);

  const second = api('verifyEmail', { token });
  assert.strictEqual(second.success, false);
  assert.strictEqual(second.code, 'TOKEN_USED');
});
check('resend verification stays generic and does not leak account state', () => {
  const known = api('resendVerificationEmail', { email: primary.email });
  const unknown = api('resendVerificationEmail', { email: 'nobody@example.com' });
  assert.strictEqual(known.success, true);
  assert.strictEqual(unknown.success, true);
  assert.strictEqual(known.message, unknown.message);
});

suite('Login & sessions');
let sessionToken = '';
let secondSession = '';

check('correct credentials create a remember-me session', () => {
  const result = api('loginUser', { email: primary.email, password: primary.password, remember: true });
  assert.strictEqual(result.success, true, JSON.stringify(result));
  sessionToken = result.data.token;
  assert.ok(sessionToken.length >= 40);
  assert.strictEqual(result.data.remember, true);
  assert.strictEqual(result.data.user.email, 'aarav.mehta@example.com');
  assert.ok(!('passwordHash' in result.data.user));
  assert.ok(!('passwordSalt' in result.data.user));

  const days = (new Date(result.data.expiresAt) - new Date()) / 86400000;
  assert.ok(days > 29 && days <= 30.1, 'remember-me session should last 30 days, got ' + days);
});
check('only token hashes are stored in Sessions', () => {
  const sheet = store.spreadsheets.get(backend.AFM_CONFIG.SPREADSHEET_ID).getSheetByName('Sessions');
  assert.ok(sheet.data.length >= 2);
  assert.ok(!JSON.stringify(sheet.data).includes(sessionToken));
  assert.match(String(sheet.data[1][2]), /^[0-9a-f]{64}$/);
});
check('session validation returns the profile without secrets', () => {
  const result = api('validateSession', {}, sessionToken);
  assert.strictEqual(result.success, true, JSON.stringify(result));
  assert.strictEqual(result.data.user.email, 'aarav.mehta@example.com');
  assert.ok(result.data.session.expiresAt);
  assert.ok(!('passwordHash' in result.data.user));
});
check('a second normal session lasts two hours', () => {
  const result = api('loginUser', { email: primary.email, password: primary.password, remember: false });
  assert.strictEqual(result.success, true);
  secondSession = result.data.token;
  const hours = (new Date(result.data.expiresAt) - new Date()) / 3600000;
  assert.ok(hours > 1.9 && hours <= 2.1, 'normal session should last 2 hours, got ' + hours);
});
check('invalid tokens and wrong passwords are rejected', () => {
  assert.strictEqual(api('validateSession', {}, 'not-a-real-token-value').code, 'SESSION_INVALID');
  const wrong = api('loginUser', { email: primary.email, password: 'Wr0ngPass!23' });
  assert.strictEqual(wrong.success, false);
  assert.strictEqual(wrong.code, 'INVALID_CREDENTIALS');
});
check('unknown emails receive the same error as wrong passwords', () => {
  const unknown = api('loginUser', { email: 'ghost@example.com', password: 'Wr0ngPass!23' });
  assert.strictEqual(unknown.code, 'INVALID_CREDENTIALS');
  assert.strictEqual(unknown.message, 'The email or password you entered is incorrect.');
});
check('expired sessions are rejected', () => {
  const sheet = store.spreadsheets.get(backend.AFM_CONFIG.SPREADSHEET_ID).getSheetByName('Sessions');
  const rowIndex = sheet.data.findIndex((row) => row[0] && row[0] === JSON.parse(backend.doPost({
    postData: { contents: JSON.stringify({ action: 'validateSession', token: secondSession, data: {} }) }
  }).getContent()).data.session.sessionId);
  assert.ok(rowIndex > 0);
  sheet.data[rowIndex][4] = new Date(Date.now() - 60000).toISOString();
  const result = api('validateSession', {}, secondSession);
  assert.strictEqual(result.success, false);
  assert.strictEqual(result.code, 'SESSION_EXPIRED');
});

suite('Profile');
check('profile loads with stats', () => {
  const result = api('getUserProfile', {}, sessionToken);
  assert.strictEqual(result.success, true);
  assert.strictEqual(result.data.user.fullName, 'Aarav Mehta');
  assert.strictEqual(result.data.user.emailVerified, true);
  assert.strictEqual(typeof result.data.stats.favorites, 'number');
});
check('profile updates are persisted and validated', () => {
  const updated = api('updateUserProfile', {
    fullName: 'Aarav S Mehta',
    mobile: '+91 90000 11111',
    gender: 'Prefer not to say',
    dob: '1994-06-15'
  }, sessionToken);
  assert.strictEqual(updated.success, true, JSON.stringify(updated));
  assert.strictEqual(updated.data.user.fullName, 'Aarav S Mehta');
  assert.strictEqual(userRow('aarav.mehta@example.com')[1], 'Aarav S Mehta');

  const invalid = api('updateUserProfile', { fullName: 'A' }, sessionToken);
  assert.strictEqual(invalid.code, 'INVALID_NAME');
});
check('password change verifies the current password and revokes other sessions', () => {
  const wrong = api('updatePassword', {
    currentPassword: 'NotIt!123',
    newPassword: 'N3wStr0ng!45',
    confirmPassword: 'N3wStr0ng!45'
  }, sessionToken);
  assert.strictEqual(wrong.code, 'INVALID_PASSWORD');

  const changed = api('updatePassword', {
    currentPassword: primary.password,
    newPassword: 'N3wStr0ng!45',
    confirmPassword: 'N3wStr0ng!45'
  }, sessionToken);
  assert.strictEqual(changed.success, true, JSON.stringify(changed));

  /* The current session survives, the other one is revoked. */
  assert.strictEqual(api('validateSession', {}, sessionToken).success, true);
  const other = api('loginUser', { email: primary.email, password: 'N3wStr0ng!45' });
  assert.strictEqual(other.success, true);
  primary.password = 'N3wStr0ng!45';
});

suite('Favorites');
let favoriteId = '';

check('adds, lists and de-duplicates favourites', () => {
  const added = api('addFavorite', {
    title: 'Zeel Clothing Black Georgette Lehenga',
    url: 'https://www.affimarts.com/2026/09/zeel-clothing-womens-black-georgette.html',
    image: 'https://m.media-amazon.com/images/I/71webzS9TiL._SY741_.jpg'
  }, sessionToken);
  assert.strictEqual(added.success, true, JSON.stringify(added));
  favoriteId = added.data.favorite.favoriteId;

  const duplicate = api('addFavorite', {
    title: 'Duplicate',
    url: 'https://www.affimarts.com/2026/09/zeel-clothing-womens-black-georgette.html'
  }, sessionToken);
  assert.strictEqual(duplicate.success, true);
  assert.strictEqual(duplicate.data.duplicate, true);

  const list = api('getFavorites', {}, sessionToken);
  assert.strictEqual(list.success, true);
  assert.strictEqual(list.data.count, 1);
  assert.strictEqual(list.data.favorites[0].favoriteId, favoriteId);
});
check('rejects unsupported product hosts and javascript URLs', () => {
  assert.strictEqual(api('addFavorite', { title: 'X', url: 'https://evil.example.com/x' }, sessionToken).code, 'INVALID_URL');
  assert.strictEqual(api('addFavorite', { title: 'X', url: 'javascript:alert(1)' }, sessionToken).code, 'INVALID_URL');
  assert.strictEqual(api('addFavorite', { title: 'X', url: 'https://www.affimarts.com/x', image: 'javascript:alert(1)' }, sessionToken).code, 'INVALID_IMAGE');
});
check('favourites are private to the session user', () => {
  const other = api('registerUser', {
    fullName: 'Diya Kapoor',
    email: 'diya@example.com',
    password: 'An0therPass!7',
    confirmPassword: 'An0therPass!7'
  });
  assert.strictEqual(other.success, true, JSON.stringify(other));
  const token = emailToken('verify', 'diya@example.com');
  assert.strictEqual(api('verifyEmail', { token }).success, true);
  const login = api('loginUser', { email: 'diya@example.com', password: 'An0therPass!7' });
  const diyaToken = login.data.token;

  const list = api('getFavorites', {}, diyaToken);
  assert.strictEqual(list.data.count, 0);
  const remove = api('removeFavorite', { favoriteId }, diyaToken);
  assert.strictEqual(remove.success, false);
  assert.strictEqual(remove.code, 'FORBIDDEN');
});
check('removes a favourite and reports missing ids', () => {
  const removed = api('removeFavorite', { favoriteId }, sessionToken);
  assert.strictEqual(removed.success, true, JSON.stringify(removed));
  assert.strictEqual(api('getFavorites', {}, sessionToken).data.count, 0);
  assert.strictEqual(api('removeFavorite', { favoriteId }, sessionToken).code, 'NOT_FOUND');
});

suite('Password reset');
check('reset requests are generic for known and unknown emails', () => {
  const known = api('requestPasswordReset', { email: primary.email });
  const unknown = api('requestPasswordReset', { email: 'missing@example.com' });
  assert.strictEqual(known.success, true);
  assert.strictEqual(unknown.success, true);
  assert.strictEqual(known.message, unknown.message);
  assert.ok(store.emails.some((mail) => mail.to === 'aarav.mehta@example.com' && /reset=/.test(mail.htmlBody)));
});
check('reset link is single use, validates strength and revokes sessions', () => {
  const token = emailToken('reset', 'aarav.mehta@example.com');

  const weak = api('resetPassword', { token, password: 'short', confirmPassword: 'short' });
  assert.strictEqual(weak.code, 'WEAK_PASSWORD');

  const done = api('resetPassword', { token, password: 'Fr3shStart!88', confirmPassword: 'Fr3shStart!88' });
  assert.strictEqual(done.success, true, JSON.stringify(done));

  const reuse = api('resetPassword', { token, password: 'Fr3shStart!88', confirmPassword: 'Fr3shStart!88' });
  assert.strictEqual(reuse.success, false);
  assert.strictEqual(reuse.code, 'TOKEN_USED');

  /* Every session created before the reset must be revoked. */
  assert.strictEqual(api('validateSession', {}, sessionToken).code, 'SESSION_INVALID');
  assert.strictEqual(api('loginUser', { email: primary.email, password: 'N3wStr0ng!45' }).code, 'INVALID_CREDENTIALS');
  const fresh = api('loginUser', { email: primary.email, password: 'Fr3shStart!88' });
  assert.strictEqual(fresh.success, true);
  sessionToken = fresh.data.token;
  primary.password = 'Fr3shStart!88';
});
check('expired reset tokens are rejected', () => {
  assert.strictEqual(api('requestPasswordReset', { email: primary.email }).success, true);
  const token = emailToken('reset', 'aarav.mehta@example.com');
  const sheet = store.spreadsheets.get(backend.AFM_CONFIG.SPREADSHEET_ID).getSheetByName('PasswordReset');
  const row = sheet.data.find((item) => item[1] && item[1] === backend.afmHashToken_(token));
  row[3] = new Date(Date.now() - 1000).toISOString();
  const result = api('resetPassword', { token, password: 'An0ther!Pass9', confirmPassword: 'An0ther!Pass9' });
  assert.strictEqual(result.success, false);
  assert.strictEqual(result.code, 'TOKEN_EXPIRED');
});

suite('Abuse protection');
check('login throttling blocks repeated failures', () => {
  const email = 'throttle@example.com';
  api('registerUser', {
    fullName: 'Throttle Test',
    email,
    password: 'An0therPass!7',
    confirmPassword: 'An0therPass!7'
  });
  let blocked = null;
  for (let i = 0; i < 8; i++) {
    const result = api('loginUser', { email, password: 'Wr0ng!Pass9' });
    if (result.code === 'TOO_MANY_REQUESTS') { blocked = result; break; }
  }
  assert.ok(blocked, 'expected the 6th attempt to be throttled');
});

suite('Logout');
check('logout revokes the current session', () => {
  const result = api('logoutUser', {}, sessionToken);
  assert.strictEqual(result.success, true);
  assert.strictEqual(api('validateSession', {}, sessionToken).code, 'SESSION_INVALID');
});
check('logoutAll revokes every session', () => {
  const login = api('loginUser', { email: primary.email, password: primary.password });
  assert.strictEqual(login.success, true);
  const token = login.data.token;
  const all = api('logoutAll', {}, token);
  assert.strictEqual(all.success, true);
  assert.strictEqual(api('validateSession', {}, token).code, 'SESSION_INVALID');
});

suite('Transport');
check('unknown actions return a structured error', () => {
  const result = api('notARealAction', {});
  assert.strictEqual(result.success, false);
  assert.strictEqual(result.code, 'UNKNOWN_ACTION');
});
check('malformed JSON returns BAD_REQUEST', () => {
  const response = backend.doPost({ postData: { contents: '{oops' } });
  const result = JSON.parse(response.getContent());
  assert.strictEqual(result.code, 'BAD_REQUEST');
});
check('health check exposes no configuration secrets', () => {
  const response = backend.doGet({ parameter: { action: 'health' } });
  const result = JSON.parse(response.getContent());
  assert.strictEqual(result.success, true);
  assert.strictEqual(result.data.status, 'ok');
  assert.ok(!JSON.stringify(result).includes('SPREADSHEET_ID'));
});

/* -------------------------------------------------------------------------- */
/*  Summary                                                                   */
/* -------------------------------------------------------------------------- */

console.log('\n' + '-'.repeat(64));
console.log('Passed: ' + passes + '   Failed: ' + failures);
if (failures > 0) process.exitCode = 1;

/**
 * ============================================================================
 * AFFIMARTS ACCOUNT — FRONTEND LOGIC TESTS (Node.js)
 * ============================================================================
 * Exercises validation.js and session.js in a minimal fake browser so the
 * shared client logic is verified without a headless browser.
 *
 * Run:  node tests/frontend.test.js
 * ============================================================================
 */
'use strict';

const assert = require('node:assert');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

/* -------------------------------------------------------------------------- */
/*  Fake browser                                                              */
/* -------------------------------------------------------------------------- */

function createStorage() {
  const map = new Map();
  return {
    getItem(key) { return map.has(key) ? map.get(key) : null; },
    setItem(key, value) { map.set(key, String(value)); },
    removeItem(key) { map.delete(key); },
    clear() { map.clear(); },
    get length() { return map.size; }
  };
}

function createBrowser(options) {
  options = options || {};
  const jar = new Map();

  const document = {
    get cookie() {
      return Array.from(jar.entries())
        .filter(([, value]) => value !== null)
        .map(([name, value]) => name + '=' + value)
        .join('; ');
    },
    set cookie(raw) {
      const [pair, ...attrs] = String(raw).split(';');
      const index = pair.indexOf('=');
      const name = pair.slice(0, index).trim();
      const value = pair.slice(index + 1).trim();
      const expired = attrs.some((attr) => /^\s*max-age\s*=\s*0\s*$/i.test(attr));
      if (!name) return;
      if (expired || value === '') jar.delete(name);
      else jar.set(name, value);
    }
  };

  const calls = [];

  const sandbox = {
    console: { log() {}, warn() {}, error() {} },
    document,
    sessionStorage: createStorage(),
    localStorage: createStorage(),
    crypto: {
      getRandomValues(bytes) {
        const buffer = crypto.randomBytes(bytes.length);
        for (let i = 0; i < bytes.length; i++) bytes[i] = buffer[i];
        return bytes;
      }
    },
    location: {
      protocol: 'https:',
      pathname: options.pathname || '/p/my-account.html',
      search: '',
      hash: '',
      href: 'https://www.affimarts.com/p/my-account.html'
    },
    navigator: { userAgent: 'node-test' },
    Intl,
    Date,
    Math,
    JSON,
    Uint8Array,
    AbortController: undefined,
    setTimeout,
    clearTimeout,
    fetch: options.fetch || function () {
      return Promise.reject(new Error('fetch not stubbed'));
    }
  };

  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.AFM_CONFIG = Object.assign({
    API_URL: 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE',
    REQUEST_TIMEOUT_MS: 30000,
    DEBUG: false
  }, options.config || {});

  const context = vm.createContext(sandbox);

  ['validation.js', 'session.js'].forEach((file) => {
    const source = fs.readFileSync(path.join(__dirname, '..', 'js', file), 'utf8');
    vm.runInContext(source, context, { filename: file });
  });

  return {
    window: sandbox,
    AFM: sandbox.AFM,
    document,
    calls,
    cookieJar: jar
  };
}

/* -------------------------------------------------------------------------- */
/*  Runner                                                                    */
/* -------------------------------------------------------------------------- */

let passes = 0;
let failures = 0;

async function check(name, fn) {
  try {
    await fn();
    passes++;
    console.log('  PASS  ' + name);
  } catch (err) {
    failures++;
    console.log('  FAIL  ' + name);
    console.log('        ' + (err && err.message ? err.message : err));
  }
}

function suite(name) {
  console.log('\n' + name);
}

/* -------------------------------------------------------------------------- */
/*  Validation                                                                */
/* -------------------------------------------------------------------------- */

(async function run() {
  const browser = createBrowser();
  const { validate } = browser.AFM;

  suite('Email validation');
  await check('accepts ordinary and internationalised addresses', () => {
    assert.strictEqual(validate.email('name@example.com').ok, true);
    assert.strictEqual(validate.email('first.last+tag@sub.example.co.uk').ok, true);
    assert.strictEqual(validate.email('  NAME@EXAMPLE.COM  ').ok, true);
  });
  await check('rejects malformed addresses', () => {
    ['', 'plain', 'a@b', 'a@@b.com', 'a b@example.com', 'a..b@example.com', 'a@-example.com']
      .forEach((value) => assert.strictEqual(validate.email(value).ok, false, value));
  });

  suite('Name validation');
  await check('accepts letters, spaces, apostrophes, dots and hyphens', () => {
    assert.strictEqual(validate.name('Aarav Mehta').ok, true);
    assert.strictEqual(validate.name("Siobhán O'Connor-Smith").ok, true);
    assert.strictEqual(validate.name('अनन्या शर्मा').ok, true);
  });
  await check('rejects markup, digits and one-letter names', () => {
    assert.strictEqual(validate.name('A').ok, false);
    assert.strictEqual(validate.name('<script>alert(1)</script>').ok, false);
    assert.strictEqual(validate.name('User123').ok, false);
  });

  suite('Phone validation');
  await check('accepts optional and international numbers', () => {
    assert.strictEqual(validate.phone('').ok, true);
    assert.strictEqual(validate.phone('+91 98765 43210').ok, true);
    assert.strictEqual(validate.phone('(020) 7946 0958').ok, true);
  });
  await check('rejects too short or lettered numbers', () => {
    assert.strictEqual(validate.phone('123').ok, false);
    assert.strictEqual(validate.phone('call-me-maybe').ok, false);
  });

  suite('Date of birth validation');
  await check('accepts a real adult date and rejects future or impossible dates', () => {
    assert.strictEqual(validate.dob('1994-06-15').ok, true);
    assert.strictEqual(validate.dob('').ok, true);
    assert.strictEqual(validate.dob('2999-01-01').ok, false);
    assert.strictEqual(validate.dob('2023-02-30').ok, false);
    assert.strictEqual(validate.dob('15/06/1994').ok, false);
  });

  suite('Password validation');
  await check('requires length, a letter, a number and no common passwords', () => {
    assert.strictEqual(validate.password('Str0ngPass!23').ok, true);
    assert.strictEqual(validate.password('short1').ok, false);
    assert.strictEqual(validate.password('alllettersonly').ok, false);
    assert.strictEqual(validate.password('password123').ok, false);
    assert.strictEqual(validate.password(' Str0ngPass1').ok, false);
  });
  await check('rejects passwords containing the email local part or name', () => {
    assert.strictEqual(validate.password('aarav1234', { email: 'aarav@example.com' }).ok, false);
    assert.strictEqual(validate.password('mehta1234', { fullName: 'Aarav Mehta' }).ok, false);
  });
  await check('strength scoring rises with complexity', () => {
    assert.ok(validate.strength('abc').score <= 1);
    assert.ok(validate.strength('Str0ngPass!23').score >= 4);
    assert.strictEqual(validate.strength('Str0ngPass!23').ok, true);
  });
  await check('confirm matches exactly', () => {
    assert.strictEqual(validate.confirm('a', 'a').ok, true);
    assert.strictEqual(validate.confirm('a', 'b').ok, false);
  });

  suite('URL validation');
  await check('accepts http(s) links and rejects script or bare text', () => {
    assert.strictEqual(validate.url('https://www.affimarts.com/p/x.html').ok, true);
    assert.strictEqual(validate.url('http://example.com').ok, true);
    assert.strictEqual(validate.url('javascript:alert(1)').ok, false);
    assert.strictEqual(validate.url('affimarts.com').ok, false);
  });

  /* ------------------------------------------------------------------------ */
  /*  Session storage                                                          */
  /* ------------------------------------------------------------------------ */

  suite('Session storage');
  await check('temporary tokens live only in sessionStorage', () => {
    const b = createBrowser();
    b.AFM.session.setToken('temp-token-123', false);
    assert.strictEqual(b.AFM.session.token(), 'temp-token-123');
    assert.strictEqual(b.window.sessionStorage.getItem('afm.token'), 'temp-token-123');
    assert.strictEqual(b.document.cookie, '');
    assert.strictEqual(b.AFM.session.hasToken(), true);
  });
  await check('remember-me tokens move to a Secure SameSite cookie', () => {
    const b = createBrowser();
    b.AFM.session.setToken('remember-token-456', true);
    assert.strictEqual(b.AFM.session.token(), 'remember-token-456');
    assert.strictEqual(b.window.sessionStorage.getItem('afm.token'), null);
    assert.match(b.document.cookie, /afm_session=remember-token-456/);
  });
  await check('clearing removes both stores', () => {
    const b = createBrowser();
    b.AFM.session.setToken('remember-token-456', true);
    b.AFM.session.clearToken();
    assert.strictEqual(b.AFM.session.token(), '');
    assert.strictEqual(b.document.cookie, '');
  });
  await check('cached user stores only public profile fields', () => {
    const b = createBrowser();
    b.AFM.session.setCachedUser({
      userId: 'AFM-20260101-ABCDEF12',
      fullName: 'Aarav Mehta',
      email: 'aarav@example.com',
      initials: 'AM',
      emailVerified: true,
      accountStatus: 'active',
      passwordHash: 'secret',
      passwordSalt: 'secret'
    });
    const cached = b.AFM.session.cachedUser();
    assert.strictEqual(cached.fullName, 'Aarav Mehta');
    assert.strictEqual(cached.initials, 'AM');
    assert.ok(!('passwordHash' in cached));
    assert.ok(!('passwordSalt' in cached));
    assert.ok(!b.window.sessionStorage.getItem('afm.user').includes('secret'));
  });
  await check('device id is stable and safe for a throttling key', () => {
    const b = createBrowser();
    const first = b.AFM.session.deviceId();
    const second = b.AFM.session.deviceId();
    assert.strictEqual(first, second);
    assert.match(first, /^[A-Za-z0-9_-]{8,64}$/);
  });

  /* ------------------------------------------------------------------------ */
  /*  API transport                                                            */
  /* ------------------------------------------------------------------------ */

  suite('API transport');
  await check('isConfigured rejects the placeholder and accepts a deployment URL', () => {
    const off = createBrowser();
    assert.strictEqual(off.AFM.api.isConfigured(), false);
    const on = createBrowser({
      config: { API_URL: 'https://script.google.com/macros/s/AKfycbTEST/exec' }
    });
    assert.strictEqual(on.AFM.api.isConfigured(), true);
  });
  await check('unconfigured calls fail with a helpful code', async () => {
    const b = createBrowser();
    await assert.rejects(b.AFM.api.request('loginUser', {}), (err) => err.code === 'NOT_CONFIGURED');
  });
  await check('POSTs JSON as text/plain with the bearer token and device id', async () => {
    let captured = null;
    const b = createBrowser({
      config: { API_URL: 'https://script.google.com/macros/s/AKfycbTEST/exec' },
      fetch(url, options) {
        captured = { url, options };
        return Promise.resolve({
          status: 200,
          text: () => Promise.resolve(JSON.stringify({
            success: true, code: 'OK', message: 'ok', data: { user: { email: 'a@b.com' } }
          }))
        });
      }
    });
    b.AFM.session.setToken('token-abc', false);
    const result = await b.AFM.api.request('validateSession', {});
    assert.strictEqual(result.success, true);
    assert.strictEqual(captured.url, 'https://script.google.com/macros/s/AKfycbTEST/exec');
    assert.strictEqual(captured.options.method, 'POST');
    assert.strictEqual(captured.options.headers['Content-Type'], 'text/plain;charset=utf-8');
    const body = JSON.parse(captured.options.body);
    assert.strictEqual(body.action, 'validateSession');
    assert.strictEqual(body.token, 'token-abc');
    assert.match(body.meta.deviceId, /^[A-Za-z0-9_-]{8,64}$/);
  });
  await check('server errors surface as ApiError with the server code', async () => {
    const b = createBrowser({
      config: { API_URL: 'https://script.google.com/macros/s/AKfycbTEST/exec' },
      fetch() {
        return Promise.resolve({
          status: 200,
          text: () => Promise.resolve(JSON.stringify({
            success: false, code: 'INVALID_CREDENTIALS', message: 'The email or password you entered is incorrect.', data: {}
          }))
        });
      }
    });
    await assert.rejects(b.AFM.api.request('loginUser', {}), (err) =>
      err.code === 'INVALID_CREDENTIALS' && /incorrect/.test(err.message));
  });
  await check('an invalid session clears stored credentials and emits an event', async () => {
    const b = createBrowser({
      config: { API_URL: 'https://script.google.com/macros/s/AKfycbTEST/exec' },
      fetch() {
        return Promise.resolve({
          status: 200,
          text: () => Promise.resolve(JSON.stringify({
            success: false, code: 'SESSION_EXPIRED', message: 'Your session has expired.', data: {}
          }))
        });
      }
    });
    let expired = 0;
    b.AFM.bus.on('session:expired', () => { expired++; });
    b.AFM.session.setToken('stale-token', true);
    await assert.rejects(b.AFM.api.request('getUserProfile', {}), (err) => err.code === 'SESSION_EXPIRED');
    assert.strictEqual(expired, 1);
    assert.strictEqual(b.AFM.session.token(), '');
  });
  await check('non-JSON responses are reported as BAD_RESPONSE', async () => {
    const b = createBrowser({
      config: { API_URL: 'https://script.google.com/macros/s/AKfycbTEST/exec' },
      fetch() {
        return Promise.resolve({ status: 200, text: () => Promise.resolve('<html>oops</html>') });
      }
    });
    await assert.rejects(b.AFM.api.request('health', {}), (err) => err.code === 'BAD_RESPONSE');
  });

  console.log('\n' + '-'.repeat(64));
  console.log('Passed: ' + passes + '   Failed: ' + failures);
  if (failures > 0) process.exitCode = 1;
})();
